package com.focuslauncher;

import android.app.Application;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.Date;

public class FocusApp extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
        final Thread.UncaughtExceptionHandler previous = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler(new Thread.UncaughtExceptionHandler() {
            @Override
            public void uncaughtException(Thread t, Throwable e) {
                try {
                    StringWriter sw = new StringWriter();
                    e.printStackTrace(new PrintWriter(sw));
                    String s = sw.toString();
                    if (s.length() > 2500) s = s.substring(0, 2500);
                    new Prefs(FocusApp.this).putStrNow("lastCrash", new Date() + "\n" + s);
                } catch (Throwable ignore) {
                    // nothing more we can do
                }
                if (previous != null) previous.uncaughtException(t, e);
            }
        });
        // Start loading the app list right away, so the launcher is ready when the screen appears.
        AppRepo.refresh(this, null);
    }
}
