package com.focuslauncher;

import android.accessibilityservice.AccessibilityService;
import android.content.Intent;
import android.os.Build;
import android.view.accessibility.AccessibilityEvent;

/**
 * Optional accessibility service. It is used only to lock the screen (double tap)
 * and to open the notification shade. It never reads screen content.
 */
public class LockService extends AccessibilityService {
    static volatile LockService instance;

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        // intentionally empty
    }

    @Override
    public void onInterrupt() {
        // intentionally empty
    }

    @Override
    public boolean onUnbind(Intent intent) {
        instance = null;
        return super.onUnbind(intent);
    }

    @Override
    public void onDestroy() {
        instance = null;
        super.onDestroy();
    }

    boolean lock() {
        if (Build.VERSION.SDK_INT >= 28) {
            return performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN);
        }
        return false;
    }

    boolean notifications() {
        return performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS);
    }
}
