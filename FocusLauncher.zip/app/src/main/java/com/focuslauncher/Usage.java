package com.focuslauncher;

import android.app.AppOpsManager;
import android.app.usage.UsageEvents;
import android.app.usage.UsageStatsManager;
import android.content.Context;
import android.content.pm.PackageManager;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Reads screen time from the system (needs "usage access", granted by the user).
 * All heavy work runs on a background thread; the UI only reads the latest snapshot.
 */
final class Usage {
    private Usage() {}

    interface Cb {
        void done(UsageData d);
    }

    private static volatile UsageData snap;
    private static volatile boolean busy = false;
    private static volatile boolean stale = false;
    private static final List<Cb> WAITERS = new ArrayList<Cb>(); // touched on the main thread only

    static boolean granted(Context c) {
        try {
            AppOpsManager ops = (AppOpsManager) c.getSystemService(Context.APP_OPS_SERVICE);
            int mode = ops.checkOpNoThrow("android:get_usage_stats", android.os.Process.myUid(), c.getPackageName());
            return mode == AppOpsManager.MODE_ALLOWED;
        } catch (Throwable ex) {
            return false;
        }
    }

    static UsageData snapshot() {
        return snap;
    }

    /** Marks the numbers as out of date (for example right after an app was used). */
    static void invalidate() {
        stale = true;
    }

    /** Recomputes in the background if needed; cb runs on the main thread. */
    static void refreshAsync(Context c, boolean force, Cb cb) {
        final Context app = c.getApplicationContext();
        UsageData cur = snap;
        long age = cur == null ? Long.MAX_VALUE : System.currentTimeMillis() - cur.at;
        if (!force && !stale && age < 20000L) {
            if (cb != null) cb.done(cur);
            return;
        }
        if (cb != null) WAITERS.add(cb);
        if (busy) return;
        busy = true;
        AppRepo.io().execute(new Runnable() {
            @Override
            public void run() {
                UsageData d = null;
                try {
                    d = compute(app);
                } catch (Throwable ignore) {
                    // no access or unsupported device
                }
                final UsageData res = d;
                AppRepo.post(new Runnable() {
                    @Override
                    public void run() {
                        if (res != null) {
                            snap = res;
                            stale = false;
                        }
                        busy = false;
                        List<Cb> copy = new ArrayList<Cb>(WAITERS);
                        WAITERS.clear();
                        for (Cb w : copy) w.done(snap);
                    }
                });
            }
        });
    }

    /** Time spent in one app today. Computes right away only when the numbers are out of date. */
    static long usedMs(Context c, String pkg) {
        UsageData d = snap;
        if (d == null || stale) {
            try {
                d = compute(c.getApplicationContext());
                snap = d;
                stale = false;
            } catch (Throwable ignore) {
                // keep the old snapshot
            }
        }
        if (d == null) return 0L;
        Long v = d.perApp.get(pkg);
        return v == null ? 0L : v;
    }

    static long totalMs() {
        UsageData d = snap;
        return d == null ? 0L : d.totalMs;
    }

    // ------------------------------------------------------------ computing

    /** Start of each of the last 7 days (index 6 is today); index 7 is the start of tomorrow. */
    static long[] dayStarts(long now) {
        Calendar cal = Calendar.getInstance();
        cal.setTimeInMillis(now);
        cal.set(Calendar.HOUR_OF_DAY, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);
        cal.add(Calendar.DAY_OF_YEAR, -6);
        long[] ds = new long[8];
        for (int i = 0; i < 8; i++) {
            ds[i] = cal.getTimeInMillis();
            cal.add(Calendar.DAY_OF_YEAR, 1);
        }
        return ds;
    }

    /** Adds one foreground span to the per-day, per-hour and per-app totals. */
    static void addSpan(UsageData d, long[] ds, String pkg, long from, long to) {
        if (to <= from || to - from > 12L * 3600000L) return; // damaged span
        for (int i = 0; i < 7; i++) {
            long a = Math.max(from, ds[i]);
            long b = Math.min(to, ds[i + 1]);
            if (b <= a) continue;
            d.days[i] += b - a;
            if (i == 6) {
                Long old = d.perApp.get(pkg);
                d.perApp.put(pkg, (old == null ? 0L : old) + (b - a));
                long today0 = ds[6];
                for (int h = (int) ((a - today0) / 3600000L); h < 24; h++) {
                    long hs = today0 + h * 3600000L;
                    if (hs >= b) break;
                    long he = hs + 3600000L;
                    d.hours[h] += Math.min(b, he) - Math.max(a, hs);
                }
            }
        }
    }

    private static boolean accept(String pkg, boolean all, Set<String> counted, String own) {
        if (pkg == null || pkg.equals(own)) return false;
        return all || counted.contains(pkg);
    }

    static UsageData compute(Context c) {
        long t0 = System.currentTimeMillis();
        UsageData d = new UsageData();
        long[] ds = dayStarts(t0);
        long today0 = ds[6];
        String own = c.getPackageName();

        // Count only real apps, and not home screens (including this launcher).
        Set<String> counted = new HashSet<String>();
        for (AppInfo a : AppRepo.get()) counted.add(a.pkg);
        counted.removeAll(Apps.homePackages(c));
        counted.remove(own);
        boolean all = counted.isEmpty(); // list not loaded yet: count everything except ourselves

        UsageStatsManager usm = (UsageStatsManager) c.getSystemService(Context.USAGE_STATS_SERVICE);
        UsageEvents ev = usm.queryEvents(ds[0], t0);
        UsageEvents.Event e = new UsageEvents.Event();
        Map<String, Long> open = new HashMap<String, Long>();
        int keyguard = 0;
        int interactive = 0;
        while (ev.hasNextEvent()) {
            ev.getNextEvent(e);
            int type = e.getEventType();
            long ts = e.getTimeStamp();
            if (type == 1) { // app came to the foreground
                String p = e.getPackageName();
                if (!open.containsKey(p)) open.put(p, ts);
            } else if (type == 2 || type == 23) { // paused / stopped
                String p = e.getPackageName();
                Long from = open.remove(p);
                if (from != null && accept(p, all, counted, own)) addSpan(d, ds, p, from, ts);
            } else if (type == 16 || type == 26) { // screen off / shutdown closes everything
                for (Map.Entry<String, Long> en : open.entrySet()) {
                    if (accept(en.getKey(), all, counted, own)) addSpan(d, ds, en.getKey(), en.getValue(), ts);
                }
                open.clear();
            } else if (type == 18) { // keyguard hidden = one unlock
                if (ts >= today0) keyguard++;
            } else if (type == 15) { // screen on
                if (ts >= today0) interactive++;
            }
        }
        for (Map.Entry<String, Long> en : open.entrySet()) {
            if (accept(en.getKey(), all, counted, own)) addSpan(d, ds, en.getKey(), en.getValue(), t0);
        }

        d.pickups = keyguard > 0 ? keyguard : interactive;
        d.totalMs = d.days[6];
        d.yesterdayMs = d.days[5];

        List<Map.Entry<String, Long>> es = new ArrayList<Map.Entry<String, Long>>(d.perApp.entrySet());
        Collections.sort(es, (x, y) -> Long.compare(y.getValue(), x.getValue()));
        PackageManager pm = c.getPackageManager();
        for (int i = 0; i < es.size() && i < 8; i++) {
            String p = es.get(i).getKey();
            d.top.add(p);
            if (i < 6) {
                try {
                    d.icons.put(p, pm.getApplicationIcon(p));
                } catch (Throwable ignore) {
                    // no icon: the row simply has none
                }
            }
        }
        d.at = System.currentTimeMillis();
        d.computeMs = d.at - t0;
        return d;
    }
}
