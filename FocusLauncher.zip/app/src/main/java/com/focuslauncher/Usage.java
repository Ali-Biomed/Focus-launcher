package com.focuslauncher;

import android.app.AppOpsManager;
import android.app.usage.UsageEvents;
import android.app.usage.UsageStatsManager;
import android.content.Context;

import java.util.Calendar;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** Reads today's screen time from the system. Needs "usage access", granted by the user. */
final class Usage {
    private Usage() {}

    private static long cacheAt = 0;
    private static Map<String, Long> cache = new HashMap<String, Long>();

    static void invalidate() {
        cacheAt = 0;
    }

    static boolean granted(Context c) {
        try {
            AppOpsManager ops = (AppOpsManager) c.getSystemService(Context.APP_OPS_SERVICE);
            int mode = ops.checkOpNoThrow("android:get_usage_stats", android.os.Process.myUid(), c.getPackageName());
            return mode == AppOpsManager.MODE_ALLOWED;
        } catch (Throwable ex) {
            return false;
        }
    }

    /** Foreground time per package since midnight, in milliseconds. */
    static Map<String, Long> today(Context c) {
        long now = System.currentTimeMillis();
        if (cacheAt != 0 && now - cacheAt < 15000) return cache;
        Map<String, Long> total = new HashMap<String, Long>();
        try {
            UsageStatsManager usm = (UsageStatsManager) c.getSystemService(Context.USAGE_STATS_SERVICE);
            Calendar cal = Calendar.getInstance();
            cal.set(Calendar.HOUR_OF_DAY, 0);
            cal.set(Calendar.MINUTE, 0);
            cal.set(Calendar.SECOND, 0);
            cal.set(Calendar.MILLISECOND, 0);
            long start = cal.getTimeInMillis();
            UsageEvents events = usm.queryEvents(start, now);
            UsageEvents.Event e = new UsageEvents.Event();
            Map<String, Long> open = new HashMap<String, Long>();
            while (events.hasNextEvent()) {
                events.getNextEvent(e);
                String pkg = e.getPackageName();
                int type = e.getEventType();
                if (type == 1) {
                    open.put(pkg, e.getTimeStamp());
                } else if (type == 2 || type == 23) {
                    Long from = open.remove(pkg);
                    if (from != null) add(total, pkg, e.getTimeStamp() - from);
                }
            }
            for (Map.Entry<String, Long> en : open.entrySet()) {
                add(total, en.getKey(), now - en.getValue());
            }
        } catch (Throwable ex) {
            // no access or unsupported device: keep what we have
        }
        cache = total;
        cacheAt = now;
        return total;
    }

    private static void add(Map<String, Long> m, String k, long v) {
        if (v <= 0) return;
        Long old = m.get(k);
        m.put(k, (old == null ? 0L : old) + v);
    }

    static long usedMs(Context c, String pkg) {
        Long v = today(c).get(pkg);
        return v == null ? 0L : v;
    }

    static long totalMs(Context c, List<AppInfo> apps) {
        Map<String, Long> m = today(c);
        Set<String> seen = new HashSet<String>();
        long sum = 0;
        for (AppInfo a : apps) {
            if (seen.add(a.pkg)) {
                Long v = m.get(a.pkg);
                if (v != null) sum += v;
            }
        }
        return sum;
    }
}
