package com.focuslauncher;

import android.content.Context;

import java.util.Locale;

/** Looks strings up by name, so a missing key shows the key instead of breaking the build. */
final class S {
    private S() {}

    static String t(Context c, String key) {
        int id = c.getResources().getIdentifier(key, "string", c.getPackageName());
        return id == 0 ? key : c.getString(id);
    }

    static String f(Context c, String key, Object... args) {
        try {
            return String.format(Locale.US, t(c, key), args);
        } catch (Exception e) {
            return t(c, key);
        }
    }
}
