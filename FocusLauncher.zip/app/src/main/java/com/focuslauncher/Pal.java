package com.focuslauncher;

/** Colors: pure black base with a small set of matching accents. */
final class Pal {
    static final int MINT = 0xFF34E0A1;
    static final int VIOLET = 0xFF8B7CFF;
    static final int CYAN = 0xFF4CC9F0;
    static final int AMBER = 0xFFFFB84D;
    static final int CORAL = 0xFFFF6B6B;

    final boolean dark;
    final int bg;
    final int card;
    final int stroke;
    final int text;
    final int dim;
    final int track;

    Pal(boolean dark) {
        this.dark = dark;
        bg = dark ? 0xFF000000 : 0xFFFFFFFF;
        card = dark ? 0xFF0F0F13 : 0xFFF3F3F6;
        stroke = dark ? 0xFF1F1F27 : 0xFFE2E2E8;
        text = dark ? 0xFFF4F4F8 : 0xFF0B0B0F;
        dim = dark ? 0xFF8C8C99 : 0xFF6A6A75;
        track = dark ? 0xFF1B1B22 : 0xFFE6E6EC;
    }
}
