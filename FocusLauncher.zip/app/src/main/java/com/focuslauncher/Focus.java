package com.focuslauncher;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

/** Focus session and schedule logic. */
final class Focus {
    private Focus() {}

    /** One schedule: days is a bit mask (bit 0 = Sunday), start/end are minutes after midnight. */
    static final class Sched {
        String name = "";
        int days = 127;
        int start = 8 * 60;
        int end = 14 * 60;
        boolean on = true;
    }

    static List<Sched> schedules(Prefs p) {
        List<Sched> out = new ArrayList<Sched>();
        for (String line : p.list("sched")) {
            String[] f = line.split("\\|", -1);
            if (f.length < 5) continue;
            try {
                Sched s = new Sched();
                s.name = f[0];
                s.days = Integer.parseInt(f[1]);
                s.start = Integer.parseInt(f[2]);
                s.end = Integer.parseInt(f[3]);
                s.on = "1".equals(f[4]);
                out.add(s);
            } catch (NumberFormatException e) {
                // skip a damaged entry
            }
        }
        return out;
    }

    static void save(Prefs p, List<Sched> list) {
        List<String> lines = new ArrayList<String>();
        for (Sched s : list) {
            String n = s.name.replace('|', ' ').replace('\n', ' ');
            lines.add(n + "|" + s.days + "|" + s.start + "|" + s.end + "|" + (s.on ? "1" : "0"));
        }
        p.putList("sched", lines);
    }

    static boolean sessionActive(Prefs p) {
        return p.lng("focusEnd", 0L) > System.currentTimeMillis();
    }

    static boolean scheduleActive(Prefs p) {
        return scheduleActive(p, Calendar.getInstance());
    }

    static boolean scheduleActive(Prefs p, Calendar c) {
        int dow = c.get(Calendar.DAY_OF_WEEK) - 1;
        int prev = (dow + 6) % 7;
        int now = c.get(Calendar.HOUR_OF_DAY) * 60 + c.get(Calendar.MINUTE);
        for (Sched s : schedules(p)) {
            if (!s.on || s.start == s.end) continue;
            boolean today = ((s.days >> dow) & 1) != 0;
            boolean yesterday = ((s.days >> prev) & 1) != 0;
            if (s.start < s.end) {
                if (today && now >= s.start && now < s.end) return true;
            } else {
                if (today && now >= s.start) return true;
                if (yesterday && now < s.end) return true;
            }
        }
        return false;
    }

    static boolean active(Prefs p) {
        return sessionActive(p) || scheduleActive(p);
    }
}
