package com.focuslauncher;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

/** Focus sessions, schedules and the small log behind the dashboard. */
final class Focus {
    private Focus() {}

    /** One schedule: days is a bit mask (bit 0 = Sunday), start/end are minutes after midnight. */
    static final class Sched {
        String name = "";
        int days = 127;
        int start = 8 * 60;
        int end = 14 * 60;
        boolean on = true;
    }

    static List<Sched> schedules(Prefs p) {
        List<Sched> out = new ArrayList<Sched>();
        for (String line : p.list("sched")) {
            String[] f = line.split("\\|", -1);
            if (f.length < 5) continue;
            try {
                Sched s = new Sched();
                s.name = f[0];
                s.days = Integer.parseInt(f[1]);
                s.start = Integer.parseInt(f[2]);
                s.end = Integer.parseInt(f[3]);
                s.on = "1".equals(f[4]);
                out.add(s);
            } catch (NumberFormatException e) {
                // skip a damaged entry
            }
        }
        return out;
    }

    static void save(Prefs p, List<Sched> list) {
        List<String> lines = new ArrayList<String>();
        for (Sched s : list) {
            String n = s.name.replace('|', ' ').replace('\n', ' ');
            lines.add(n + "|" + s.days + "|" + s.start + "|" + s.end + "|" + (s.on ? "1" : "0"));
        }
        p.putList("sched", lines);
    }

    static boolean sessionActive(Prefs p) {
        return p.lng("focusEnd", 0L) > System.currentTimeMillis();
    }

    static boolean scheduleActive(Prefs p) {
        return scheduleActive(p, Calendar.getInstance());
    }

    static boolean scheduleActive(Prefs p, Calendar c) {
        int dow = c.get(Calendar.DAY_OF_WEEK) - 1;
        int prev = (dow + 6) % 7;
        int now = c.get(Calendar.HOUR_OF_DAY) * 60 + c.get(Calendar.MINUTE);
        for (Sched s : schedules(p)) {
            if (!s.on || s.start == s.end) continue;
            boolean today = ((s.days >> dow) & 1) != 0;
            boolean yesterday = ((s.days >> prev) & 1) != 0;
            if (s.start < s.end) {
                if (today && now >= s.start && now < s.end) return true;
            } else {
                if (today && now >= s.start) return true;
                if (yesterday && now < s.end) return true;
            }
        }
        return false;
    }

    static boolean active(Prefs p) {
        return sessionActive(p) || scheduleActive(p);
    }

    // ------------------------------------------------------------- session log

    static String dayKey(long t) {
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(t);
        return String.format(Locale.US, "%04d%02d%02d",
                c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH));
    }

    static void startSession(Prefs p, int minutes) {
        settle(p);
        long now = System.currentTimeMillis();
        p.putLng("focusStart", now);
        p.putLng("focusEnd", now + minutes * 60000L);
        p.putBool("focusLogged", false);
    }

    /** Ends the running session now and logs the time that was actually spent. */
    static void endSession(Prefs p) {
        long now = System.currentTimeMillis();
        long start = p.lng("focusStart", 0L);
        long end = p.lng("focusEnd", 0L);
        if (end > now && start > 0L && !p.bool("focusLogged", true)) log(p, start, now);
        p.putLng("focusEnd", 0L);
        p.putBool("focusLogged", true);
    }

    /** Logs a session that ran to its end, once. */
    static void settle(Prefs p) {
        long start = p.lng("focusStart", 0L);
        long end = p.lng("focusEnd", 0L);
        if (end == 0L || start == 0L || p.bool("focusLogged", true)) return;
        if (System.currentTimeMillis() >= end) {
            log(p, start, end);
            p.putBool("focusLogged", true);
        }
    }

    private static void log(Prefs p, long from, long to) {
        int m = (int) Math.max(0L, (to - from) / 60000L);
        if (m <= 0) return;
        String k = "fl_" + dayKey(from);
        p.putNum(k, p.num(k, 0) + m);
    }

    /** Focus minutes today, including a session that is still running. */
    static int minutesToday(Prefs p) {
        settle(p);
        long now = System.currentTimeMillis();
        int m = p.num("fl_" + dayKey(now), 0);
        long start = p.lng("focusStart", 0L);
        long end = p.lng("focusEnd", 0L);
        if (end > now && start > 0L && !p.bool("focusLogged", true) && dayKey(start).equals(dayKey(now))) {
            m += (int) ((now - start) / 60000L);
        }
        return m;
    }

    /** Consecutive days with some focus time (today counts once it has any). */
    static int streak(Prefs p) {
        Calendar c = Calendar.getInstance();
        int today = minutesToday(p);
        if (today < 1) c.add(Calendar.DAY_OF_YEAR, -1);
        int s = 0;
        for (int i = 0; i < 365; i++) {
            int m = (i == 0 && today >= 1) ? today : p.num("fl_" + dayKey(c.getTimeInMillis()), 0);
            if (m < 1) break;
            s++;
            c.add(Calendar.DAY_OF_YEAR, -1);
        }
        return s;
    }
}
