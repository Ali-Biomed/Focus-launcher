package com.focuslauncher;

import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

final class Apps {
    private Apps() {}

    /** All launchable apps except this launcher, sorted by name. */
    static List<AppInfo> load(Context c, Prefs p) {
        PackageManager pm = c.getPackageManager();
        Intent i = new Intent(Intent.ACTION_MAIN);
        i.addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> found = pm.queryIntentActivities(i, 0);
        List<AppInfo> out = new ArrayList<AppInfo>();
        for (ResolveInfo ri : found) {
            ActivityInfo ai = ri.activityInfo;
            if (ai == null || c.getPackageName().equals(ai.packageName)) continue;
            AppInfo a = new AppInfo(String.valueOf(ri.loadLabel(pm)), ai.packageName, ai.name);
            String custom = p.str("name_" + a.key, "");
            if (custom != null && custom.length() > 0) a.setDisplay(custom);
            out.add(a);
        }
        Collections.sort(out, new Comparator<AppInfo>() {
            @Override
            public int compare(AppInfo x, AppInfo y) {
                return x.norm.compareTo(y.norm);
            }
        });
        return out;
    }

    /** Packages of every installed home screen app (they are not counted as "usage"). */
    static Set<String> homePackages(Context c) {
        Set<String> out = new HashSet<String>();
        try {
            Intent i = new Intent(Intent.ACTION_MAIN);
            i.addCategory(Intent.CATEGORY_HOME);
            for (ResolveInfo ri : c.getPackageManager().queryIntentActivities(i, 0)) {
                if (ri.activityInfo != null) out.add(ri.activityInfo.packageName);
            }
        } catch (Throwable ignore) {
            // keep what we have
        }
        return out;
    }
}
