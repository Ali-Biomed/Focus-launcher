package com.focuslauncher;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.SweepGradient;
import android.view.View;
import android.view.animation.DecelerateInterpolator;

/** Small hand-drawn charts for the dashboard (no libraries). */
final class Charts {
    private Charts() {}

    static int lerp(int a, int b, float t) {
        int aa = (a >>> 24) & 0xFF;
        int ar = (a >>> 16) & 0xFF;
        int ag = (a >>> 8) & 0xFF;
        int ab = a & 0xFF;
        int ba = (b >>> 24) & 0xFF;
        int br = (b >>> 16) & 0xFF;
        int bg = (b >>> 8) & 0xFF;
        int bb = b & 0xFF;
        int ra = (int) (aa + (ba - aa) * t);
        int rr = (int) (ar + (br - ar) * t);
        int rg = (int) (ag + (bg - ag) * t);
        int rb = (int) (ab + (bb - ab) * t);
        return (ra << 24) | (rr << 16) | (rg << 8) | rb;
    }

    /** A circular progress arc with a color gradient. */
    static final class Ring extends View {
        private final Paint track = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint arc = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF box = new RectF();
        private final Matrix rot = new Matrix();
        private float shown = 0f;
        private float target = 0f;
        private int c1 = Pal.MINT;
        private int c2 = Pal.CYAN;
        private ValueAnimator anim;

        Ring(Context c, int trackColor) {
            super(c);
            track.setStyle(Paint.Style.STROKE);
            track.setColor(trackColor);
            track.setStrokeCap(Paint.Cap.ROUND);
            arc.setStyle(Paint.Style.STROKE);
            arc.setStrokeCap(Paint.Cap.ROUND);
        }

        void set(float fraction, int from, int to, boolean fromZero) {
            target = Math.max(0f, Math.min(1f, fraction));
            c1 = from;
            c2 = to;
            rebuildShader();
            if (anim != null) anim.cancel();
            if (fromZero) shown = 0f;
            if (Math.abs(shown - target) < 0.002f) {
                shown = target;
                invalidate();
                return;
            }
            anim = ValueAnimator.ofFloat(shown, target);
            anim.setDuration(850);
            anim.setInterpolator(new DecelerateInterpolator());
            anim.addUpdateListener(a -> {
                shown = (Float) a.getAnimatedValue();
                invalidate();
            });
            anim.start();
        }

        private void rebuildShader() {
            if (getWidth() == 0) return;
            float cx = getWidth() / 2f;
            float cy = getHeight() / 2f;
            SweepGradient g = new SweepGradient(cx, cy, new int[]{c1, c2}, new float[]{0f, 1f});
            rot.setRotate(-90f, cx, cy);
            g.setLocalMatrix(rot);
            arc.setShader(g);
        }

        @Override
        protected void onSizeChanged(int w, int h, int ow, int oh) {
            super.onSizeChanged(w, h, ow, oh);
            float s = Math.min(w, h);
            float stroke = s * 0.085f;
            track.setStrokeWidth(stroke);
            arc.setStrokeWidth(stroke);
            float pad = stroke / 2f + 2f;
            box.set((w - s) / 2f + pad, (h - s) / 2f + pad, (w + s) / 2f - pad, (h + s) / 2f - pad);
            rebuildShader();
        }

        @Override
        protected void onDraw(Canvas cv) {
            cv.drawArc(box, 0f, 360f, false, track);
            if (shown > 0.001f) cv.drawArc(box, -90f, 360f * shown, false, arc);
        }

        @Override
        protected void onDetachedFromWindow() {
            if (anim != null) anim.cancel();
            super.onDetachedFromWindow();
        }
    }

    /** Rounded vertical columns that grow in one after another. */
    static final class Columns extends View {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF r = new RectF();
        private final int emptyColor;
        private float[] target = new float[0];
        private int[] colors = new int[0];
        private float t = 1f;
        private ValueAnimator anim;

        Columns(Context c, int emptyColor) {
            super(c);
            this.emptyColor = emptyColor;
        }

        void set(float[] values, int[] cols, boolean animate) {
            target = values;
            colors = cols;
            if (anim != null) anim.cancel();
            if (!animate) {
                t = 1f;
                invalidate();
                return;
            }
            t = 0f;
            anim = ValueAnimator.ofFloat(0f, 1f);
            anim.setDuration(750);
            anim.setInterpolator(new DecelerateInterpolator());
            anim.addUpdateListener(a -> {
                t = (Float) a.getAnimatedValue();
                invalidate();
            });
            anim.start();
        }

        @Override
        protected void onDraw(Canvas cv) {
            int n = target.length;
            if (n == 0) return;
            float w = getWidth();
            float h = getHeight();
            float slot = w / n;
            float bw = slot * 0.66f;
            float rad = bw / 2f;
            for (int i = 0; i < n; i++) {
                float ti = Math.max(0f, Math.min(1f, t * 1.6f - 0.6f * i / n));
                float ch = Math.max(bw, target[i] * ti * h);
                float x = i * slot + (slot - bw) / 2f;
                boolean empty = target[i] <= 0.0001f;
                paint.setColor(empty || i >= colors.length ? emptyColor : colors[i]);
                r.set(x, h - ch, x + bw, h);
                cv.drawRoundRect(r, rad, rad, paint);
            }
        }

        @Override
        protected void onDetachedFromWindow() {
            if (anim != null) anim.cancel();
            super.onDetachedFromWindow();
        }
    }

    /** A thin horizontal progress bar with a gradient. */
    static final class Bar extends View {
        private final Paint track = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF r = new RectF();
        private float shown = 0f;
        private float target = 0f;
        private int c1 = Pal.VIOLET;
        private int c2 = Pal.CYAN;
        private ValueAnimator anim;

        Bar(Context c, int trackColor) {
            super(c);
            track.setColor(trackColor);
        }

        void set(float fraction, int from, int to, boolean fromZero) {
            target = Math.max(0f, Math.min(1f, fraction));
            c1 = from;
            c2 = to;
            rebuildShader();
            if (anim != null) anim.cancel();
            if (fromZero) shown = 0f;
            anim = ValueAnimator.ofFloat(shown, target);
            anim.setDuration(650);
            anim.setInterpolator(new DecelerateInterpolator());
            anim.addUpdateListener(a -> {
                shown = (Float) a.getAnimatedValue();
                invalidate();
            });
            anim.start();
        }

        private void rebuildShader() {
            if (getWidth() == 0) return;
            fill.setShader(new LinearGradient(0f, 0f, getWidth(), 0f, c1, c2, Shader.TileMode.CLAMP));
        }

        @Override
        protected void onSizeChanged(int w, int h, int ow, int oh) {
            super.onSizeChanged(w, h, ow, oh);
            rebuildShader();
        }

        @Override
        protected void onDraw(Canvas cv) {
            float w = getWidth();
            float h = getHeight();
            float rad = h / 2f;
            boolean rtl = getLayoutDirection() == View.LAYOUT_DIRECTION_RTL;
            if (rtl) cv.scale(-1f, 1f, w / 2f, h / 2f);
            r.set(0f, 0f, w, h);
            cv.drawRoundRect(r, rad, rad, track);
            if (shown > 0.001f) {
                r.set(0f, 0f, Math.max(h, w * shown), h);
                cv.drawRoundRect(r, rad, rad, fill);
            }
        }

        @Override
        protected void onDetachedFromWindow() {
            if (anim != null) anim.cancel();
            super.onDetachedFromWindow();
        }
    }
}
