package com.focuslauncher;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.TimePickerDialog;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.res.Configuration;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.os.Looper;
import android.provider.AlarmClock;
import android.provider.MediaStore;
import android.provider.Settings;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.text.format.DateFormat;
import android.view.GestureDetector;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DateFormatSymbols;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/**
 * Focus Launcher: one activity that shows the home screen, the app list and the settings.
 * Everything is built in code, so there are no layout files to get out of sync.
 */
public class MainActivity extends Activity {

    interface StrCb {
        void done(String s);
    }

    interface IntCb {
        void done(int v);
    }

    // ------------------------------------------------------------------ state

    private Prefs prefs;
    private FrameLayout root;
    private LinearLayout homeView;
    private LinearLayout homeList;
    private LinearLayout drawerView;
    private LinearLayout drawerList;
    private TextView clockView;
    private TextView dateView;
    private TextView usageView;
    private TextView focusView;
    private EditText searchBox;
    private ScrollView settingsScroll;
    private GestureDetector gestures;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private List<AppInfo> apps = new ArrayList<AppInfo>();
    private List<AppInfo> results = new ArrayList<AppInfo>();
    private long appsAt = 0;
    private long usageAt = 0;
    private int mode = 0; // 0 = home, 1 = app list, 2 = settings
    private boolean dark;
    private boolean ar;
    private boolean lastFocus;
    private int bg;
    private int fg;
    private int dim;
    private float downX;
    private float downY;
    private long downT;
    private Runnable autoRun;

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            if (mode == 0) updateClock();
            handler.postDelayed(this, 1000);
        }
    };

    // -------------------------------------------------------------- lifecycle

    @Override
    protected void attachBaseContext(Context base) {
        String lang = base.getSharedPreferences("focus_prefs", Context.MODE_PRIVATE).getString("lang", "auto");
        if (lang != null && !"auto".equals(lang)) {
            Locale l = Locale.forLanguageTag(lang);
            Locale.setDefault(l);
            Configuration cfg = new Configuration(base.getResources().getConfiguration());
            cfg.setLocale(l);
            base = base.createConfigurationContext(cfg);
        }
        super.attachBaseContext(base);
    }

    @Override
    protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        prefs = new Prefs(this);
        ar = "ar".equals(getResources().getConfiguration().getLocales().get(0).getLanguage());
        resolveColors();
        applyWindow();
        root = new FrameLayout(this);
        root.setBackgroundColor(bg);
        setContentView(root);
        gestures = new GestureDetector(this, new GestureDetector.SimpleOnGestureListener() {
            @Override
            public boolean onDoubleTap(MotionEvent e) {
                if (mode == 0 && prefs.bool("dtLock", true)) lockScreen();
                return true;
            }
        });
        buildHome();
        buildDrawer();
        if (saved != null && saved.getInt("mode", 0) == 2) showSettings();
        else showHome();
        if (!prefs.bool("onboarded", false)) onboard();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        showHome();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (mode == 0) refreshHome();
        else if (mode == 2) rebuildSettings();
        handler.removeCallbacks(tick);
        handler.post(tick);
    }

    @Override
    protected void onPause() {
        super.onPause();
        handler.removeCallbacks(tick);
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        out.putInt("mode", mode);
    }

    @Override
    public void onBackPressed() {
        if (mode != 0) showHome();
    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
        boolean onHome = mode == 0;
        if (onHome) gestures.onTouchEvent(ev);
        int act = ev.getActionMasked();
        if (onHome && act == MotionEvent.ACTION_DOWN) {
            downX = ev.getX();
            downY = ev.getY();
            downT = ev.getEventTime();
        }
        float ux = ev.getX();
        float uy = ev.getY();
        long ut = ev.getEventTime();
        boolean r = super.dispatchTouchEvent(ev);
        if (onHome && act == MotionEvent.ACTION_UP) handleSwipe(ux - downX, uy - downY, ut - downT);
        return r;
    }

    // ---------------------------------------------------------------- helpers

    private String t(String key) {
        return S.t(this, key);
    }

    private String f(String key, Object... args) {
        return S.f(this, key, args);
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private TextView text(String s, float sp, int color) {
        TextView v = new TextView(this);
        v.setText(s);
        v.setTextSize(sp);
        v.setTextColor(color);
        return v;
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }

    private void startSafe(Intent i) {
        try {
            startActivity(i);
        } catch (Exception e) {
            toast(t("err_open"));
        }
    }

    private AlertDialog.Builder dialog() {
        int theme = dark ? android.R.style.Theme_DeviceDefault_Dialog_Alert
                : android.R.style.Theme_DeviceDefault_Light_Dialog_Alert;
        return new AlertDialog.Builder(this, theme);
    }

    private void choose(String title, String[] items, DialogInterface.OnClickListener l) {
        dialog().setTitle(title).setItems(items, l).setNegativeButton(t("cancel"), null).show();
    }

    private void prompt(String title, String initial, final StrCb cb) {
        final EditText et = new EditText(this);
        et.setTextColor(fg);
        et.setSingleLine(true);
        et.setText(initial);
        et.setSelection(et.getText().length());
        FrameLayout box = new FrameLayout(this);
        box.setPadding(dp(20), dp(8), dp(20), 0);
        box.addView(et);
        dialog().setTitle(title).setView(box)
                .setPositiveButton(t("save"), (d, w) -> cb.done(et.getText().toString().trim()))
                .setNegativeButton(t("cancel"), null)
                .show();
    }

    /** A confirmation whose "continue" button only works after a short wait. */
    private void showDelayDialog(String title, String msg, int secs, final String goLabel, final Runnable go) {
        final AlertDialog d = dialog().setTitle(title).setMessage(msg)
                .setNegativeButton(t("back"), null)
                .setPositiveButton(goLabel, (di, w) -> go.run())
                .create();
        d.show();
        final Button pos = d.getButton(AlertDialog.BUTTON_POSITIVE);
        pos.setEnabled(false);
        final CountDownTimer timer = new CountDownTimer(secs * 1000L, 1000L) {
            @Override
            public void onTick(long ms) {
                pos.setText(goLabel + " (" + (ms / 1000 + 1) + ")");
            }

            @Override
            public void onFinish() {
                pos.setText(goLabel);
                pos.setEnabled(true);
            }
        };
        d.setOnDismissListener(di -> timer.cancel());
        timer.start();
    }

    // ---------------------------------------------------------- colors, window

    private void resolveColors() {
        String th = prefs.str("theme", "dark");
        if ("auto".equals(th)) {
            int night = getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK;
            dark = night == Configuration.UI_MODE_NIGHT_YES;
        } else {
            dark = !"light".equals(th);
        }
        bg = dark ? 0xFF000000 : 0xFFFFFFFF;
        fg = dark ? 0xFFFFFFFF : 0xFF000000;
        dim = dark ? 0xFF8E8E8E : 0xFF6B6B6B;
    }

    private void applyWindow() {
        Window w = getWindow();
        w.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        w.setStatusBarColor(bg);
        w.setNavigationBarColor(bg);
        int flags = 0;
        if (!dark) {
            flags = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
        }
        w.getDecorView().setSystemUiVisibility(flags);
        if (prefs.bool("statusBar", true)) {
            w.clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
        } else {
            w.addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
        }
    }

    private void setScreen(View v) {
        root.removeAllViews();
        root.addView(v, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
    }

    // ------------------------------------------------------------------- apps

    private void ensureApps() {
        long now = System.currentTimeMillis();
        if (appsAt == 0 || now - appsAt > 20000) {
            apps = Apps.load(this, prefs);
            appsAt = now;
        }
    }

    private void reloadApps() {
        appsAt = 0;
        ensureApps();
    }

    private AppInfo byKey(String key) {
        ensureApps();
        for (AppInfo a : apps) {
            if (a.key.equals(key)) return a;
        }
        return null;
    }

    private String labelFor(String pkg) {
        for (AppInfo a : apps) {
            if (a.pkg.equals(pkg)) return a.display;
        }
        return pkg;
    }

    /** Apps that may be shown right now: not hidden, and not blocked by an active focus mode. */
    private List<AppInfo> visibleApps() {
        ensureApps();
        Set<String> hidden = prefs.set("hidden");
        Set<String> blocked = Focus.active(prefs) ? prefs.set("distract") : new HashSet<String>();
        List<AppInfo> out = new ArrayList<AppInfo>();
        for (AppInfo a : apps) {
            if (!hidden.contains(a.pkg) && !blocked.contains(a.pkg)) out.add(a);
        }
        return out;
    }

    // ------------------------------------------------------------------- home

    private void buildHome() {
        homeView = new LinearLayout(this);
        homeView.setOrientation(LinearLayout.VERTICAL);
        homeView.setPadding(dp(28), dp(24), dp(28), dp(24));
        homeView.setOnLongClickListener(v -> {
            showSettings();
            return true;
        });

        clockView = text("", 54, fg);
        clockView.setTypeface(Typeface.create("sans-serif-light", Typeface.NORMAL));
        clockView.setOnClickListener(v -> startSafe(new Intent(AlarmClock.ACTION_SHOW_ALARMS)));
        dateView = text("", 16, dim);
        usageView = text("", 14, dim);
        usageView.setVisibility(View.GONE);

        homeList = new LinearLayout(this);
        homeList.setOrientation(LinearLayout.VERTICAL);
        homeList.setGravity(Gravity.CENTER_VERTICAL);

        focusView = text("", 15, dim);
        focusView.setPadding(0, dp(12), 0, dp(12));
        focusView.setOnClickListener(v -> onFocusTap());

        homeView.addView(clockView);
        homeView.addView(dateView);
        homeView.addView(usageView);
        homeView.addView(homeList, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        homeView.addView(focusView);
    }

    private void showHome() {
        mode = 0;
        hideKeyboard();
        if (autoRun != null) {
            handler.removeCallbacks(autoRun);
            autoRun = null;
        }
        setScreen(homeView);
        refreshHome();
    }

    private int alignGravity() {
        int a = prefs.num("align", 0);
        if (a == 1) return Gravity.CENTER_HORIZONTAL;
        if (a == 2) return Gravity.END;
        return Gravity.START;
    }

    private void refreshHome() {
        lastFocus = Focus.active(prefs);
        int g = alignGravity();
        clockView.setGravity(g);
        dateView.setGravity(g);
        usageView.setGravity(g);
        focusView.setGravity(g);
        int[] sizes = {22, 28, 34};
        float sz = sizes[Math.max(0, Math.min(2, prefs.num("textSize", 1)))];
        homeList.removeAllViews();
        Set<String> blocked = lastFocus ? prefs.set("distract") : new HashSet<String>();
        int count = 0;
        for (String k : prefs.list("home")) {
            final AppInfo a = byKey(k);
            if (a == null || blocked.contains(a.pkg)) continue;
            TextView tv = text(a.display, sz, fg);
            tv.setGravity(g);
            tv.setPadding(0, dp(9), 0, dp(9));
            tv.setOnClickListener(v -> openApp(a));
            tv.setOnLongClickListener(v -> {
                showAppMenu(a);
                return true;
            });
            homeList.addView(tv);
            count++;
        }
        if (count == 0) {
            TextView hint = text(t("home_hint"), 15, dim);
            hint.setGravity(g);
            homeList.addView(hint);
        }
        updateClock();
        refreshUsageLine();
    }

    private void updateClock() {
        Date now = new Date();
        boolean h24 = DateFormat.is24HourFormat(this);
        clockView.setText(new SimpleDateFormat(h24 ? "HH:mm" : "h:mm", Locale.US).format(now));
        Locale dl = ar ? Locale.forLanguageTag("ar-u-nu-latn") : Locale.ENGLISH;
        dateView.setText(new SimpleDateFormat("EEEE, d MMMM", dl).format(now));

        long left = prefs.lng("focusEnd", 0L) - System.currentTimeMillis();
        boolean on = Focus.active(prefs);
        if (left > 0) focusView.setText(f("focus_running", mmss(left)));
        else if (on) focusView.setText(t("focus_scheduled"));
        else focusView.setText(t("focus_start"));

        if (on != lastFocus) {
            refreshHome();
            return;
        }
        if (prefs.bool("showUsage", false) && System.currentTimeMillis() - usageAt > 60000) {
            refreshUsageLine();
        }
    }

    private String mmss(long ms) {
        long s = ms / 1000;
        return String.format(Locale.US, "%d:%02d", s / 60, s % 60);
    }

    private String dur(long ms) {
        long m = ms / 60000;
        if (m < 60) return f("dur_m", m);
        return f("dur_hm", m / 60, m % 60);
    }

    private void refreshUsageLine() {
        usageAt = System.currentTimeMillis();
        if (!prefs.bool("showUsage", false) || !Usage.granted(this)) {
            usageView.setText("");
            usageView.setVisibility(View.GONE);
            return;
        }
        ensureApps();
        usageView.setVisibility(View.VISIBLE);
        usageView.setText(f("usage_today", dur(Usage.totalMs(this, apps))));
    }

    // ------------------------------------------------------------ app list

    private void buildDrawer() {
        drawerView = new LinearLayout(this);
        drawerView.setOrientation(LinearLayout.VERTICAL);
        drawerView.setPadding(dp(24), dp(16), dp(24), dp(8));

        searchBox = new EditText(this);
        searchBox.setBackground(null);
        searchBox.setSingleLine(true);
        searchBox.setTextSize(24);
        searchBox.setTextColor(fg);
        searchBox.setHintTextColor(dim);
        searchBox.setHint(t("search_hint"));
        searchBox.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        searchBox.setImeOptions(EditorInfo.IME_ACTION_GO);
        searchBox.setPadding(dp(4), dp(10), dp(4), dp(10));
        searchBox.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                filter(s.toString());
            }
        });
        searchBox.setOnEditorActionListener((v, actionId, event) -> {
            if (!results.isEmpty()) openApp(results.get(0));
            return true;
        });

        ScrollView sv = new ScrollView(this);
        sv.setVerticalScrollBarEnabled(false);
        drawerList = new LinearLayout(this);
        drawerList.setOrientation(LinearLayout.VERTICAL);
        sv.addView(drawerList);

        drawerView.addView(searchBox);
        drawerView.addView(sv, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
    }

    private void openDrawer() {
        mode = 1;
        setScreen(drawerView);
        searchBox.setText("");
        if (prefs.bool("autoKb", true)) {
            searchBox.requestFocus();
            handler.postDelayed(() -> {
                InputMethodManager im = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                if (im != null) im.showSoftInput(searchBox, InputMethodManager.SHOW_IMPLICIT);
            }, 150);
        }
    }

    private void hideKeyboard() {
        InputMethodManager im = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (im != null && root != null) im.hideSoftInputFromWindow(root.getWindowToken(), 0);
    }

    private void filter(String q) {
        String n = Norm.n(q);
        List<AppInfo> starts = new ArrayList<AppInfo>();
        List<AppInfo> contains = new ArrayList<AppInfo>();
        for (AppInfo a : visibleApps()) {
            if (n.length() == 0 || a.norm.startsWith(n)) starts.add(a);
            else if (a.all.contains(n)) contains.add(a);
        }
        starts.addAll(contains);
        results = starts;
        renderDrawer();
        scheduleAuto(n);
    }

    private void renderDrawer() {
        drawerList.removeAllViews();
        for (final AppInfo a : results) {
            TextView tv = text(a.display, 22, fg);
            tv.setPadding(dp(4), dp(11), dp(4), dp(11));
            tv.setOnClickListener(v -> openApp(a));
            tv.setOnLongClickListener(v -> {
                showAppMenu(a);
                return true;
            });
            drawerList.addView(tv);
        }
        if (results.isEmpty()) {
            drawerList.addView(text(t("no_results"), 16, dim));
        }
    }

    private void scheduleAuto(String n) {
        if (autoRun != null) {
            handler.removeCallbacks(autoRun);
            autoRun = null;
        }
        if (!prefs.bool("autoOpen", true) || n.length() < 2 || results.size() != 1) return;
        final AppInfo a = results.get(0);
        autoRun = () -> {
            autoRun = null;
            if (mode == 1) openApp(a);
        };
        handler.postDelayed(autoRun, 700);
    }

    // ----------------------------------------------------------- launching

    private void openApp(final AppInfo a) {
        boolean distracting = prefs.set("distract").contains(a.pkg);
        if (distracting && Focus.active(prefs)) {
            showBlocked();
            return;
        }
        int lim = prefs.num("limit_" + a.pkg, 0);
        if (lim > 0 && Usage.granted(this) && Usage.usedMs(this, a.pkg) >= lim * 60000L) {
            showDelayDialog(t("limit_title"), f("limit_msg", a.display, lim), 15, t("override"), () -> launch(a));
            return;
        }
        int secs = prefs.num("pause", 5);
        if (distracting && secs > 0) {
            showDelayDialog(t("pause_title"), t("pause_msg"), secs, t("go_on"), () -> launch(a));
            return;
        }
        launch(a);
    }

    private void launch(AppInfo a) {
        hideKeyboard();
        try {
            Intent i = new Intent(Intent.ACTION_MAIN);
            i.addCategory(Intent.CATEGORY_LAUNCHER);
            i.setClassName(a.pkg, a.cls);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
            showHome();
            startActivity(i);
            Usage.invalidate();
        } catch (Exception e) {
            toast(t("err_open"));
        }
    }

    private void showBlocked() {
        AlertDialog.Builder b = dialog().setTitle(t("blocked_title")).setMessage(t("blocked_msg"))
                .setPositiveButton(t("ok"), null);
        if (Focus.sessionActive(prefs)) {
            b.setNeutralButton(t("end_session"), (d, w) -> endSessionWithDelay());
        }
        b.show();
    }

    private void endSessionWithDelay() {
        showDelayDialog(t("end_session"), t("end_session_msg"), 10, t("end_session"), () -> {
            prefs.putLng("focusEnd", 0L);
            afterChange();
        });
    }

    private void onFocusTap() {
        if (Focus.sessionActive(prefs)) {
            endSessionWithDelay();
            return;
        }
        final int[] mins = {15, 25, 45, 60, 90};
        String[] items = new String[mins.length];
        for (int i = 0; i < mins.length; i++) items[i] = f("minutes", mins[i]);
        choose(t("focus_pick"), items, (d, which) -> startSession(mins[which]));
    }

    private void startSession(int minutes) {
        prefs.putLng("focusEnd", System.currentTimeMillis() + minutes * 60000L);
        afterChange();
    }

    private void swipeAction(String k) {
        String key = prefs.str(k, "");
        AppInfo a = (key == null || key.length() == 0) ? null : byKey(key);
        if (a != null) {
            openApp(a);
            return;
        }
        try {
            Intent i = "swipeLeft".equals(k)
                    ? new Intent(Intent.ACTION_DIAL)
                    : new Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        } catch (Exception e) {
            toast(t("err_open"));
        }
    }

    private void handleSwipe(float dx, float dy, long dt) {
        if (dt > 900) return;
        float min = dp(90);
        float ax = Math.abs(dx);
        float ay = Math.abs(dy);
        if (ay > ax * 1.5f && ay > min) {
            if (dy < 0) openDrawer();
            else openNotifications();
        } else if (ax > ay * 1.5f && ax > min) {
            swipeAction(dx < 0 ? "swipeLeft" : "swipeRight");
        }
    }

    private void lockScreen() {
        if (Build.VERSION.SDK_INT < 28) {
            toast(t("lock_old"));
            return;
        }
        LockService s = LockService.instance;
        if (s == null) {
            toast(t("lock_enable"));
            return;
        }
        s.lock();
    }

    private void openNotifications() {
        try {
            Object bar = getSystemService("statusbar");
            Class<?> cls = Class.forName("android.app.StatusBarManager");
            cls.getMethod("expandNotificationsPanel").invoke(bar);
        } catch (Throwable e) {
            LockService s = LockService.instance;
            if (s != null) s.notifications();
        }
    }

    // ------------------------------------------------------------ app menu

    private void afterChange() {
        if (mode == 0) refreshHome();
        else if (mode == 1) filter(searchBox.getText().toString());
        else rebuildSettings();
    }

    private void showAppMenu(final AppInfo a) {
        final List<String> labels = new ArrayList<String>();
        final List<Runnable> acts = new ArrayList<Runnable>();
        final List<String> home = prefs.list("home");
        if (home.contains(a.key)) {
            labels.add(t("m_unhome"));
            acts.add(() -> {
                home.remove(a.key);
                prefs.putList("home", home);
                afterChange();
            });
            if (home.indexOf(a.key) > 0) {
                labels.add(t("m_up"));
                acts.add(() -> {
                    int i = home.indexOf(a.key);
                    Collections.swap(home, i, i - 1);
                    prefs.putList("home", home);
                    afterChange();
                });
            }
        } else {
            labels.add(t("m_home"));
            acts.add(() -> addToHome(a));
        }
        labels.add(t("m_rename"));
        acts.add(() -> renameApp(a));
        labels.add(t("m_hide"));
        acts.add(() -> {
            Set<String> h = prefs.set("hidden");
            h.add(a.pkg);
            prefs.putSet("hidden", h);
            afterChange();
        });
        final boolean distracting = prefs.set("distract").contains(a.pkg);
        labels.add(distracting ? t("m_undistract") : t("m_distract"));
        acts.add(() -> {
            Set<String> s = prefs.set("distract");
            if (distracting) s.remove(a.pkg);
            else s.add(a.pkg);
            prefs.putSet("distract", s);
            afterChange();
        });
        labels.add(t("m_limit"));
        acts.add(() -> chooseLimit(a.pkg));
        labels.add(t("m_info"));
        acts.add(() -> startSafe(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                Uri.parse("package:" + a.pkg))));
        labels.add(t("m_uninstall"));
        acts.add(() -> startSafe(new Intent(Intent.ACTION_DELETE, Uri.parse("package:" + a.pkg))));

        final String[] arr = labels.toArray(new String[0]);
        dialog().setTitle(a.display).setItems(arr, (d, which) -> acts.get(which).run()).show();
    }

    private void addToHome(AppInfo a) {
        List<String> h = prefs.list("home");
        int max = prefs.num("homeMax", 5);
        if (h.size() >= max) {
            toast(f("home_full", max));
            return;
        }
        h.add(a.key);
        prefs.putList("home", h);
        toast(t("added"));
        afterChange();
    }

    private void renameApp(final AppInfo a) {
        prompt(t("rename"), a.display, s -> {
            if (s.length() == 0) prefs.remove("name_" + a.key);
            else prefs.putStr("name_" + a.key, s);
            reloadApps();
            afterChange();
        });
    }

    private void chooseLimit(final String pkg) {
        final int[] vals = {0, 15, 30, 45, 60, 90, 120, 180};
        String[] items = new String[vals.length];
        for (int i = 0; i < vals.length; i++) {
            items[i] = vals[i] == 0 ? t("no_limit") : f("minutes", vals[i]);
        }
        choose(t("limit_pick"), items, (d, which) -> {
            if (vals[which] == 0) prefs.remove("limit_" + pkg);
            else prefs.putNum("limit_" + pkg, vals[which]);
            if (vals[which] > 0 && !Usage.granted(this)) showUsageHelp();
            if (mode == 2) rebuildSettings();
        });
    }

    // ------------------------------------------------------------ settings

    private TextView section(String s) {
        TextView v = text(s, 13, dim);
        v.setPadding(0, dp(24), 0, dp(4));
        return v;
    }

    private View row(String title, String value, View.OnClickListener l) {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.VERTICAL);
        r.setPadding(0, dp(11), 0, dp(11));
        r.addView(text(title, 18, fg));
        if (value != null && value.length() > 0) r.addView(text(value, 14, dim));
        r.setOnClickListener(l);
        return r;
    }

    private View toggleRow(String title, final String key, final boolean def, final Runnable after) {
        boolean on = prefs.bool(key, def);
        return row(title, on ? t("on") : t("off"), v -> {
            prefs.putBool(key, !prefs.bool(key, def));
            if (after != null) after.run();
            rebuildSettings();
        });
    }

    private String mark(boolean ok) {
        return ok ? "\u2713  " : "\u2717  ";
    }

    private String idxLabel(String[] labels, String key, int def) {
        int i = prefs.num(key, def);
        return labels[Math.max(0, Math.min(labels.length - 1, i))];
    }

    private void chooseIdx(String title, String[] labels, final String key) {
        choose(title, labels, (d, which) -> {
            prefs.putNum(key, which);
            rebuildSettings();
        });
    }

    private void chooseNum(String title, final int[] vals, final String key) {
        String[] items = new String[vals.length];
        for (int i = 0; i < vals.length; i++) {
            items[i] = vals[i] == 0 ? t("off") : String.valueOf(vals[i]);
        }
        choose(title, items, (d, which) -> {
            prefs.putNum(key, vals[which]);
            rebuildSettings();
        });
    }

    private String swipeLabel(String key, String dflt) {
        String k = prefs.str(key, "");
        if (k == null || k.length() == 0) return dflt;
        AppInfo a = byKey(k);
        return a == null ? dflt : a.display;
    }

    private void chooseSwipeApp(final String key, String title, String dflt) {
        ensureApps();
        final List<AppInfo> list = new ArrayList<AppInfo>(apps);
        String[] items = new String[list.size() + 1];
        items[0] = dflt;
        for (int i = 0; i < list.size(); i++) items[i + 1] = list.get(i).display;
        choose(title, items, (d, which) -> {
            if (which == 0) prefs.remove(key);
            else prefs.putStr(key, list.get(which - 1).key);
            rebuildSettings();
        });
    }

    private void rebuildSettings() {
        int y = settingsScroll == null ? 0 : settingsScroll.getScrollY();
        showSettings();
        final int fy = y;
        settingsScroll.post(() -> settingsScroll.scrollTo(0, fy));
    }

    private void showSettings() {
        mode = 2;
        hideKeyboard();
        settingsScroll = new ScrollView(this);
        settingsScroll.setBackgroundColor(bg);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(24), dp(16), dp(24), dp(48));
        settingsScroll.addView(col);

        col.addView(text(t("settings"), 30, fg));
        TextView back = text(t("done"), 16, dim);
        back.setPadding(0, dp(8), 0, dp(8));
        back.setOnClickListener(v -> showHome());
        col.addView(back);

        // ---- setup
        col.addView(section(t("sec_setup")));
        col.addView(row(mark(isDefaultLauncher()) + t("set_default"), t("set_default_d"),
                v -> startSafe(new Intent(Settings.ACTION_HOME_SETTINGS))));
        col.addView(row(mark(lockServiceEnabled()) + t("set_lock"), t("set_lock_d"),
                v -> showA11yHelp()));
        col.addView(row(mark(Usage.granted(this)) + t("set_usage"), t("set_usage_d"),
                v -> showUsageHelp()));
        col.addView(row(t("set_wake"), t("set_wake_d"), v -> showWakeHelp()));

        // ---- home screen
        col.addView(section(t("sec_home")));
        col.addView(row(t("home_count"), String.valueOf(prefs.num("homeMax", 5)),
                v -> chooseNum(t("home_count"), new int[]{2, 3, 4, 5, 6, 7, 8}, "homeMax")));
        final String[] sizes = {t("small"), t("medium"), t("large")};
        col.addView(row(t("text_size"), idxLabel(sizes, "textSize", 1),
                v -> chooseIdx(t("text_size"), sizes, "textSize")));
        final String[] aligns = {t("align_start"), t("align_center"), t("align_end")};
        col.addView(row(t("align"), idxLabel(aligns, "align", 0),
                v -> chooseIdx(t("align"), aligns, "align")));
        String th = prefs.str("theme", "dark");
        String thLabel = "auto".equals(th) ? t("auto") : "light".equals(th) ? t("light") : t("dark");
        col.addView(row(t("theme"), thLabel, v -> choose(t("theme"),
                new String[]{t("auto"), t("dark"), t("light")}, (d, which) -> {
                    prefs.putStr("theme", which == 0 ? "auto" : which == 1 ? "dark" : "light");
                    recreate();
                })));
        String lang = prefs.str("lang", "auto");
        String langLabel = "ar".equals(lang) ? t("lang_ar") : "en".equals(lang) ? t("lang_en") : t("auto");
        col.addView(row(t("language"), langLabel, v -> choose(t("language"),
                new String[]{t("auto"), t("lang_ar"), t("lang_en")}, (d, which) -> {
                    prefs.putStr("lang", which == 1 ? "ar" : which == 2 ? "en" : "auto");
                    recreate();
                })));
        col.addView(toggleRow(t("status_bar"), "statusBar", true, this::applyWindow));
        col.addView(toggleRow(t("show_usage"), "showUsage", false, () -> {
            if (prefs.bool("showUsage", false) && !Usage.granted(this)) showUsageHelp();
        }));

        // ---- gestures and search
        col.addView(section(t("sec_gest")));
        col.addView(toggleRow(t("dt_lock"), "dtLock", true, null));
        col.addView(row(t("swipe_left"), swipeLabel("swipeLeft", t("default_left")),
                v -> chooseSwipeApp("swipeLeft", t("swipe_left"), t("default_left"))));
        col.addView(row(t("swipe_right"), swipeLabel("swipeRight", t("default_right")),
                v -> chooseSwipeApp("swipeRight", t("swipe_right"), t("default_right"))));
        col.addView(toggleRow(t("auto_open"), "autoOpen", true, null));
        col.addView(toggleRow(t("auto_kb"), "autoKb", true, null));

        // ---- focus
        col.addView(section(t("sec_focus")));
        col.addView(row(Focus.sessionActive(prefs) ? t("end_session") : t("start_session"), "",
                v -> onFocusTap()));
        col.addView(row(t("distract_apps"), f("n_apps", prefs.set("distract").size()),
                v -> pickApps(t("distract_apps"), "distract")));
        int secs = prefs.num("pause", 5);
        col.addView(row(t("pause_secs"), secs == 0 ? t("off") : f("seconds", secs),
                v -> chooseNum(t("pause_secs"), new int[]{0, 3, 5, 10, 15}, "pause")));
        col.addView(row(t("limits"), f("n_apps", limitedPkgs().size()), v -> showLimits()));
        col.addView(row(t("schedules"), String.valueOf(Focus.schedules(prefs).size()),
                v -> showSchedules()));
        col.addView(row(t("report"), "", v -> showReport()));

        // ---- apps
        col.addView(section(t("sec_apps")));
        col.addView(row(t("hidden_apps"), f("n_apps", prefs.set("hidden").size()),
                v -> pickApps(t("hidden_apps"), "hidden")));

        // ---- about
        col.addView(section(t("sec_about")));
        col.addView(row(t("about_title"), t("about_d"), null));

        setScreen(settingsScroll);
    }

    private void pickApps(String title, final String key) {
        ensureApps();
        final LinkedHashMap<String, String> m = new LinkedHashMap<String, String>();
        for (AppInfo a : apps) {
            if (!m.containsKey(a.pkg)) m.put(a.pkg, a.display);
        }
        final String[] pk = m.keySet().toArray(new String[0]);
        String[] names = m.values().toArray(new String[0]);
        final Set<String> sel = prefs.set(key);
        final boolean[] on = new boolean[pk.length];
        for (int i = 0; i < pk.length; i++) on[i] = sel.contains(pk[i]);
        dialog().setTitle(title)
                .setMultiChoiceItems(names, on, (d, which, checked) -> {
                    if (checked) sel.add(pk[which]);
                    else sel.remove(pk[which]);
                })
                .setPositiveButton(t("save"), (d, w) -> {
                    prefs.putSet(key, sel);
                    afterChange();
                })
                .setNegativeButton(t("cancel"), null)
                .show();
    }

    // ---- daily limits

    private List<String> limitedPkgs() {
        ensureApps();
        List<String> out = new ArrayList<String>();
        for (AppInfo a : apps) {
            if (!out.contains(a.pkg) && prefs.num("limit_" + a.pkg, 0) > 0) out.add(a.pkg);
        }
        return out;
    }

    private void showLimits() {
        final List<String> pk = limitedPkgs();
        String[] items = new String[pk.size() + 1];
        for (int i = 0; i < pk.size(); i++) {
            items[i] = labelFor(pk.get(i)) + "  \u2014  " + f("minutes", prefs.num("limit_" + pk.get(i), 0));
        }
        items[pk.size()] = "+  " + t("add");
        choose(t("limits"), items, (d, which) -> {
            if (which < pk.size()) chooseLimit(pk.get(which));
            else pickAppForLimit();
        });
    }

    private void pickAppForLimit() {
        ensureApps();
        final List<String> pk = new ArrayList<String>();
        List<String> names = new ArrayList<String>();
        for (AppInfo a : apps) {
            if (!pk.contains(a.pkg)) {
                pk.add(a.pkg);
                names.add(a.display);
            }
        }
        choose(t("limits"), names.toArray(new String[0]), (d, which) -> chooseLimit(pk.get(which)));
    }

    // ---- screen time report

    private static long usedOf(Map<String, Long> m, String pkg) {
        Long v = m.get(pkg);
        return v == null ? 0L : v;
    }

    private void showReport() {
        if (!Usage.granted(this)) {
            showUsageHelp();
            return;
        }
        ensureApps();
        Usage.invalidate();
        final Map<String, Long> m = Usage.today(this);
        List<AppInfo> uniq = new ArrayList<AppInfo>();
        Set<String> seen = new HashSet<String>();
        for (AppInfo a : apps) {
            if (seen.add(a.pkg)) uniq.add(a);
        }
        Collections.sort(uniq, (x, y) -> Long.compare(usedOf(m, y.pkg), usedOf(m, x.pkg)));
        StringBuilder sb = new StringBuilder();
        long total = 0;
        int listed = 0;
        for (AppInfo a : uniq) {
            long ms = usedOf(m, a.pkg);
            total += ms;
            if (ms >= 60000 && listed < 15) {
                sb.append(a.display).append("  \u2014  ").append(dur(ms)).append('\n');
                listed++;
            }
        }
        if (listed == 0) sb.append(t("report_empty"));
        else sb.insert(0, f("report_total", dur(total)) + "\n\n");
        dialog().setTitle(t("report_title")).setMessage(sb.toString())
                .setPositiveButton(t("ok"), null).show();
    }

    // ---- schedules

    private String hhmm(int minutes) {
        return String.format(Locale.US, "%02d:%02d", minutes / 60, minutes % 60);
    }

    private Locale dayLocale() {
        return ar ? Locale.forLanguageTag("ar-u-nu-latn") : Locale.ENGLISH;
    }

    private String[] dayLabels() {
        String[] w = new DateFormatSymbols(dayLocale()).getWeekdays();
        String[] out = new String[7];
        for (int i = 0; i < 7; i++) out[i] = w[i + 1];
        return out;
    }

    private String daysText(int mask) {
        if (mask == 127) return t("every_day");
        String[] w = new DateFormatSymbols(dayLocale()).getShortWeekdays();
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 7; i++) {
            if (((mask >> i) & 1) != 0) {
                if (sb.length() > 0) sb.append(' ');
                sb.append(w[i + 1]);
            }
        }
        return sb.toString();
    }

    private String describe(Focus.Sched s) {
        return (s.on ? "\u25CF " : "\u25CB ") + s.name + "  " + daysText(s.days) + "  "
                + hhmm(s.start) + " - " + hhmm(s.end);
    }

    private void showSchedules() {
        final List<Focus.Sched> list = Focus.schedules(prefs);
        String[] items = new String[list.size() + 1];
        for (int i = 0; i < list.size(); i++) items[i] = describe(list.get(i));
        items[list.size()] = "+  " + t("add");
        choose(t("schedules"), items, (d, which) -> {
            if (which == list.size()) scheduleWizard(new Focus.Sched(), -1);
            else editSchedule(list, which);
        });
    }

    private void editSchedule(final List<Focus.Sched> list, final int idx) {
        final Focus.Sched s = list.get(idx);
        choose(s.name, new String[]{t("s_toggle"), t("s_edit"), t("s_delete")}, (d, which) -> {
            if (which == 0) {
                s.on = !s.on;
                Focus.save(prefs, list);
                rebuildSettings();
            } else if (which == 1) {
                scheduleWizard(s, idx);
            } else {
                list.remove(idx);
                Focus.save(prefs, list);
                rebuildSettings();
            }
        });
    }

    private void scheduleWizard(final Focus.Sched s, final int index) {
        prompt(t("sched_name"), s.name, name -> {
            s.name = name.length() == 0 ? t("sched_default") : name;
            pickDays(s, () -> pickTime(t("sched_start"), s.start, st -> {
                s.start = st;
                pickTime(t("sched_end"), s.end, en -> {
                    s.end = en;
                    List<Focus.Sched> all = Focus.schedules(prefs);
                    if (index < 0 || index >= all.size()) all.add(s);
                    else all.set(index, s);
                    Focus.save(prefs, all);
                    rebuildSettings();
                });
            }));
        });
    }

    private void pickDays(final Focus.Sched s, final Runnable next) {
        final String[] names = dayLabels();
        final boolean[] on = new boolean[7];
        for (int i = 0; i < 7; i++) on[i] = ((s.days >> i) & 1) != 0;
        dialog().setTitle(t("sched_days"))
                .setMultiChoiceItems(names, on, (d, which, checked) -> on[which] = checked)
                .setPositiveButton(t("next"), (d, w) -> {
                    int mask = 0;
                    for (int i = 0; i < 7; i++) {
                        if (on[i]) mask |= (1 << i);
                    }
                    s.days = mask == 0 ? 127 : mask;
                    next.run();
                })
                .setNegativeButton(t("cancel"), null)
                .show();
    }

    private void pickTime(String title, int minutes, final IntCb cb) {
        int theme = dark ? android.R.style.Theme_DeviceDefault_Dialog
                : android.R.style.Theme_DeviceDefault_Light_Dialog;
        TimePickerDialog d = new TimePickerDialog(this, theme,
                (view, h, m) -> cb.done(h * 60 + m), minutes / 60, minutes % 60, true);
        d.setTitle(title);
        d.show();
    }

    // ---- help dialogs and setup checks

    private void showA11yHelp() {
        dialog().setTitle(t("a11y_title")).setMessage(t("a11y_msg"))
                .setPositiveButton(t("a11y_open"),
                        (d, w) -> startSafe(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)))
                .setNeutralButton(t("m_info"),
                        (d, w) -> startSafe(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                                Uri.parse("package:" + getPackageName()))))
                .setNegativeButton(t("cancel"), null)
                .show();
    }

    private void showUsageHelp() {
        dialog().setTitle(t("usage_title")).setMessage(t("usage_msg"))
                .setPositiveButton(t("open_settings"),
                        (d, w) -> startSafe(new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)))
                .setNegativeButton(t("cancel"), null)
                .show();
    }

    private void showWakeHelp() {
        dialog().setTitle(t("wake_title")).setMessage(t("wake_msg"))
                .setPositiveButton(t("wake_open"),
                        (d, w) -> startSafe(new Intent(Settings.ACTION_DISPLAY_SETTINGS)))
                .setNegativeButton(t("cancel"), null)
                .show();
    }

    private void onboard() {
        prefs.putBool("onboarded", true);
        dialog().setTitle(t("welcome_title")).setMessage(t("welcome_msg"))
                .setPositiveButton(t("open_settings"), (d, w) -> showSettings())
                .setNegativeButton(t("later"), null)
                .show();
    }

    private boolean isDefaultLauncher() {
        Intent i = new Intent(Intent.ACTION_MAIN);
        i.addCategory(Intent.CATEGORY_HOME);
        ResolveInfo ri = getPackageManager().resolveActivity(i, PackageManager.MATCH_DEFAULT_ONLY);
        return ri != null && ri.activityInfo != null
                && getPackageName().equals(ri.activityInfo.packageName);
    }

    private boolean lockServiceEnabled() {
        String s = Settings.Secure.getString(getContentResolver(),
                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        if (s == null || s.length() == 0) return false;
        for (String part : s.split(":")) {
            ComponentName cn = ComponentName.unflattenFromString(part);
            if (cn != null && cn.getPackageName().equals(getPackageName())
                    && cn.getClassName().equals(LockService.class.getName())) {
                return true;
            }
        }
        return false;
    }
}
