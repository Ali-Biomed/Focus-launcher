package com.focuslauncher;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.TimePickerDialog;
import android.app.admin.DevicePolicyManager;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.res.Configuration;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.os.Looper;
import android.provider.AlarmClock;
import android.provider.MediaStore;
import android.provider.Settings;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.text.format.DateFormat;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.DecelerateInterpolator;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DateFormatSymbols;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/**
 * Focus Launcher: one activity that shows the home screen, the dashboard, the app list and the settings.
 * Everything is built in code, so there are no layout files to get out of sync.
 */
public class MainActivity extends Activity {

    interface StrCb {
        void done(String s);
    }

    interface IntCb {
        void done(int v);
    }

    static final String VERSION = "2.0";

    // ------------------------------------------------------------------ state

    private Prefs prefs;
    private Pal pal;
    private FrameLayout root;
    private GestureLayer pager;
    private Dash dash;
    private LinearLayout homeView;
    private LinearLayout homeList;
    private LinearLayout drawerView;
    private ListView drawerListView;
    private TextView emptyHint;
    private AppAdapter adapter;
    private TextView clockView;
    private TextView dateView;
    private TextView usageView;
    private TextView focusView;
    private EditText searchBox;
    private ScrollView settingsScroll;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private List<AppInfo> results = new ArrayList<AppInfo>();
    private int mode = 0; // 0 = home, 1 = app list, 2 = settings, 3 = dashboard
    private boolean dark;
    private boolean ar;
    private boolean lastFocus;
    private int bg;
    private int fg;
    private int dim;
    private long dashAt = 0L;
    private Runnable autoRun;

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            if (mode == 0 || mode == 3) updateClock();
            long now = System.currentTimeMillis();
            if (mode == 3 && now - dashAt > 30000L) refreshDash(false);
            long delay = Focus.sessionActive(prefs) ? 1000L : (60000L - now % 60000L + 50L);
            handler.postDelayed(this, delay);
        }
    };

    // -------------------------------------------------------------- lifecycle

    @Override
    protected void attachBaseContext(Context base) {
        String lang = base.getSharedPreferences("focus_prefs", Context.MODE_PRIVATE).getString("lang", "auto");
        if (lang != null && !"auto".equals(lang)) {
            Locale l = Locale.forLanguageTag(lang);
            Locale.setDefault(l);
            Configuration cfg = new Configuration(base.getResources().getConfiguration());
            cfg.setLocale(l);
            base = base.createConfigurationContext(cfg);
        }
        super.attachBaseContext(base);
    }

    @Override
    protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        prefs = new Prefs(this);
        ar = "ar".equals(getResources().getConfiguration().getLocales().get(0).getLanguage());
        resolveColors();
        applyWindow();
        root = new FrameLayout(this);
        root.setBackgroundColor(bg);
        setContentView(root);
        buildHome();
        buildDash();
        buildPager();
        buildDrawer();
        if (saved != null && saved.getInt("mode", 0) == 2) showSettings();
        else showHome();
        if (!prefs.bool("onboarded", false)) onboard();
        AppRepo.refreshIfStale(this, 20000L, this::onAppsLoaded);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        showHome();
    }

    @Override
    protected void onResume() {
        super.onResume();
        Focus.settle(prefs);
        AppRepo.refreshIfStale(this, 30000L, this::onAppsLoaded);
        if (Usage.granted(this)) Usage.refreshAsync(this, false, d -> onUsage());
        if (mode == 0 || mode == 3) refreshHome();
        else if (mode == 2) rebuildSettings();
        handler.removeCallbacks(tick);
        handler.post(tick);
    }

    @Override
    protected void onPause() {
        super.onPause();
        handler.removeCallbacks(tick);
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        out.putInt("mode", mode);
    }

    @Override
    public void onBackPressed() {
        if (mode == 3) pager.showPage(0, true);
        else if (mode != 0) showHome();
    }

    private void onAppsLoaded() {
        if (mode == 0 || mode == 3) refreshHome();
        else if (mode == 1) filter(searchBox.getText().toString());
        else if (mode == 2) rebuildSettings();
        if (mode == 3) bindDash(Usage.snapshot(), Usage.granted(this));
    }

    private void onUsage() {
        refreshUsageLine();
        if (mode == 3) bindDash(Usage.snapshot(), true);
    }

    // ---------------------------------------------------------------- helpers

    private String t(String key) {
        return S.t(this, key);
    }

    private String f(String key, Object... args) {
        return S.f(this, key, args);
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private TextView text(String s, float sp, int color) {
        TextView v = new TextView(this);
        v.setText(s);
        v.setTextSize(sp);
        v.setTextColor(color);
        return v;
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }

    private void startSafe(Intent i) {
        try {
            startActivity(i);
        } catch (Exception e) {
            toast(t("err_open"));
        }
    }

    private AlertDialog.Builder dialog() {
        int theme = dark ? android.R.style.Theme_DeviceDefault_Dialog_Alert
                : android.R.style.Theme_DeviceDefault_Light_Dialog_Alert;
        return new AlertDialog.Builder(this, theme);
    }

    private void choose(String title, String[] items, DialogInterface.OnClickListener l) {
        dialog().setTitle(title).setItems(items, l).setNegativeButton(t("cancel"), null).show();
    }

    private void prompt(String title, String initial, final StrCb cb) {
        final EditText et = new EditText(this);
        et.setTextColor(fg);
        et.setSingleLine(true);
        et.setText(initial);
        et.setSelection(et.getText().length());
        FrameLayout box = new FrameLayout(this);
        box.setPadding(dp(20), dp(8), dp(20), 0);
        box.addView(et);
        dialog().setTitle(title).setView(box)
                .setPositiveButton(t("save"), (d, w) -> cb.done(et.getText().toString().trim()))
                .setNegativeButton(t("cancel"), null)
                .show();
    }

    /** A confirmation whose "continue" button only works after a short wait. */
    private void showDelayDialog(String title, String msg, int secs, final String goLabel, final Runnable go) {
        final AlertDialog d = dialog().setTitle(title).setMessage(msg)
                .setNegativeButton(t("back"), null)
                .setPositiveButton(goLabel, (di, w) -> go.run())
                .create();
        d.show();
        final Button pos = d.getButton(AlertDialog.BUTTON_POSITIVE);
        pos.setEnabled(false);
        final CountDownTimer timer = new CountDownTimer(secs * 1000L, 1000L) {
            @Override
            public void onTick(long ms) {
                pos.setText(goLabel + " (" + (ms / 1000 + 1) + ")");
            }

            @Override
            public void onFinish() {
                pos.setText(goLabel);
                pos.setEnabled(true);
            }
        };
        d.setOnDismissListener(di -> timer.cancel());
        timer.start();
    }

    private String dur(long ms) {
        long m = ms / 60000L;
        if (m < 60) return f("dur_m", m);
        return f("dur_hm", m / 60, m % 60);
    }

    // ---------------------------------------------------------- colors, window

    private void resolveColors() {
        String th = prefs.str("theme", "dark");
        if ("auto".equals(th)) {
            int night = getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK;
            dark = night == Configuration.UI_MODE_NIGHT_YES;
        } else {
            dark = !"light".equals(th);
        }
        pal = new Pal(dark);
        bg = pal.bg;
        fg = pal.text;
        dim = pal.dim;
    }

    private void applyWindow() {
        Window w = getWindow();
        w.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        w.setStatusBarColor(bg);
        w.setNavigationBarColor(bg);
        int flags = 0;
        if (!dark) {
            flags = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
        }
        w.getDecorView().setSystemUiVisibility(flags);
        if (prefs.bool("statusBar", true)) {
            w.clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
        } else {
            w.addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
        }
    }

    private void setScreen(View v) {
        root.removeAllViews();
        root.addView(v, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
    }

    private void setScreenAnimated(View v) {
        setScreen(v);
        v.animate().cancel();
        v.setAlpha(0f);
        v.setTranslationY(dp(26));
        v.animate().alpha(1f).translationY(0f).setDuration(210)
                .setInterpolator(new DecelerateInterpolator()).start();
    }

    // ------------------------------------------------------------------- apps

    private AppInfo findKey(String key) {
        for (AppInfo a : AppRepo.get()) {
            if (a.key.equals(key)) return a;
        }
        return null;
    }

    private AppInfo firstByPkg(String pkg) {
        for (AppInfo a : AppRepo.get()) {
            if (a.pkg.equals(pkg)) return a;
        }
        return null;
    }

    /** The app for a saved key. Before the list has loaded it is rebuilt from the saved name. */
    private AppInfo appForKey(String key) {
        AppInfo a = findKey(key);
        if (a != null) return a;
        if (AppRepo.ready()) return null; // the list is loaded and this app is gone
        int i = key.indexOf('/');
        if (i <= 0) return null;
        String label = prefs.str("hl_" + key, null);
        String pkg = key.substring(0, i);
        return new AppInfo(label == null ? pkg : label, pkg, key.substring(i + 1));
    }

    private String labelFor(String pkg) {
        AppInfo a = firstByPkg(pkg);
        return a == null ? pkg : a.display;
    }

    /** Apps that may be shown right now: not hidden, and not blocked by an active focus mode. */
    private List<AppInfo> visibleApps() {
        Set<String> hidden = prefs.set("hidden");
        Set<String> blocked = Focus.active(prefs) ? prefs.set("distract") : new HashSet<String>();
        List<AppInfo> out = new ArrayList<AppInfo>();
        for (AppInfo a : AppRepo.get()) {
            if (!hidden.contains(a.pkg) && !blocked.contains(a.pkg)) out.add(a);
        }
        return out;
    }

    // ------------------------------------------------------------------- home

    private void buildHome() {
        homeView = new LinearLayout(this);
        homeView.setOrientation(LinearLayout.VERTICAL);
        homeView.setPadding(dp(28), dp(24), dp(28), dp(24));
        homeView.setOnLongClickListener(v -> {
            showSettings();
            return true;
        });

        clockView = text("", 54, fg);
        clockView.setTypeface(Typeface.create("sans-serif-light", Typeface.NORMAL));
        clockView.setOnClickListener(v -> startSafe(new Intent(AlarmClock.ACTION_SHOW_ALARMS)));
        dateView = text("", 16, dim);
        usageView = text("", 14, dim);
        usageView.setVisibility(View.GONE);

        homeList = new LinearLayout(this);
        homeList.setOrientation(LinearLayout.VERTICAL);
        homeList.setGravity(Gravity.CENTER_VERTICAL);

        focusView = text("", 15, dim);
        focusView.setPadding(0, dp(12), 0, dp(12));
        focusView.setOnClickListener(v -> onFocusTap());

        homeView.addView(clockView);
        homeView.addView(dateView);
        homeView.addView(usageView);
        homeView.addView(homeList, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        homeView.addView(focusView);
    }

    private void buildDash() {
        dash = new Dash(this, pal, ar, new Dash.Actions() {
            @Override
            public void startFocus() {
                onFocusTap();
            }

            @Override
            public void setGoal() {
                chooseGoal();
            }

            @Override
            public void needUsage() {
                showUsageHelp();
            }

            @Override
            public void appMenu(String pkg) {
                AppInfo a = firstByPkg(pkg);
                if (a != null) showAppMenu(a);
            }
        });
    }

    private void buildPager() {
        pager = new GestureLayer(this);
        pager.setPages(homeView, dash.view());
        pager.setListener(new GestureLayer.Listener() {
            @Override
            public void onDoubleTap() {
                if (mode == 0 && prefs.bool("dtLock", true)) lockScreen();
            }

            @Override
            public void onSwipeUp() {
                if (mode == 0) openDrawer();
            }

            @Override
            public void onSwipeDown() {
                if (mode == 0) openNotifications();
            }

            @Override
            public void onSwipeRight() {
                if (mode == 0) swipeAction("swipeRight");
            }

            @Override
            public void onOpening() {
                refreshDash(false);
            }

            @Override
            public void onPage(int page) {
                mode = page == 1 ? 3 : 0;
                if (page == 1) {
                    dash.onShown();
                    refreshDash(false);
                } else {
                    dash.onHidden();
                }
            }
        });
    }

    private void showHome() {
        mode = 0;
        hideKeyboard();
        if (autoRun != null) {
            handler.removeCallbacks(autoRun);
            autoRun = null;
        }
        setScreen(pager);
        pager.showPage(0, false);
        dash.onHidden();
        refreshHome();
    }

    private int alignGravity() {
        int a = prefs.num("align", 0);
        if (a == 1) return Gravity.CENTER_HORIZONTAL;
        if (a == 2) return Gravity.END;
        return Gravity.START;
    }

    private void refreshHome() {
        lastFocus = Focus.active(prefs);
        int g = alignGravity();
        clockView.setGravity(g);
        dateView.setGravity(g);
        usageView.setGravity(g);
        focusView.setGravity(g);
        int[] sizes = {22, 28, 34};
        float sz = sizes[Math.max(0, Math.min(2, prefs.num("textSize", 1)))];
        homeList.removeAllViews();
        Set<String> blocked = lastFocus ? prefs.set("distract") : new HashSet<String>();
        int count = 0;
        for (String k : prefs.list("home")) {
            final AppInfo a = appForKey(k);
            if (a == null || blocked.contains(a.pkg)) continue;
            if (AppRepo.ready() && !a.display.equals(prefs.str("hl_" + a.key, null))) {
                prefs.putStr("hl_" + a.key, a.display);
            }
            TextView tv = text(a.display, sz, fg);
            tv.setGravity(g);
            tv.setPadding(0, dp(9), 0, dp(9));
            tv.setOnClickListener(v -> openApp(a));
            tv.setOnLongClickListener(v -> {
                showAppMenu(a);
                return true;
            });
            homeList.addView(tv);
            count++;
        }
        if (count == 0) {
            TextView hint = text(t("home_hint"), 15, dim);
            hint.setGravity(g);
            homeList.addView(hint);
        }
        updateClock();
        refreshUsageLine();
    }

    private void updateClock() {
        Date now = new Date();
        boolean h24 = DateFormat.is24HourFormat(this);
        clockView.setText(new SimpleDateFormat(h24 ? "HH:mm" : "h:mm", Locale.US).format(now));
        Locale dl = ar ? Locale.forLanguageTag("ar-u-nu-latn") : Locale.ENGLISH;
        dateView.setText(new SimpleDateFormat("EEEE, d MMMM", dl).format(now));

        long left = prefs.lng("focusEnd", 0L) - System.currentTimeMillis();
        boolean on = Focus.active(prefs);
        if (left > 0) focusView.setText(f("focus_running", mmss(left)));
        else if (on) focusView.setText(t("focus_scheduled"));
        else focusView.setText(t("focus_start"));

        if (on != lastFocus) {
            Focus.settle(prefs);
            refreshHome();
        }
    }

    private String mmss(long ms) {
        long s = ms / 1000;
        return String.format(Locale.US, "%d:%02d", s / 60, s % 60);
    }

    private void refreshUsageLine() {
        UsageData d = Usage.snapshot();
        if (!prefs.bool("showUsage", false) || d == null || !Usage.granted(this)) {
            usageView.setText("");
            usageView.setVisibility(View.GONE);
            return;
        }
        usageView.setVisibility(View.VISIBLE);
        usageView.setText(f("usage_today", dur(d.totalMs)));
    }

    // --------------------------------------------------------------- dashboard

    private void refreshDash(boolean force) {
        dashAt = System.currentTimeMillis();
        if (!Usage.granted(this)) {
            bindDash(null, false);
            return;
        }
        Usage.refreshAsync(this, force, d -> bindDash(d, true));
    }

    private void bindDash(UsageData d, boolean access) {
        Dash.Model m = new Dash.Model();
        m.usage = d != null ? d : Usage.snapshot();
        m.names = new HashMap<String, String>();
        for (AppInfo a : AppRepo.get()) {
            if (!m.names.containsKey(a.pkg)) m.names.put(a.pkg, a.display);
        }
        m.distracting = prefs.set("distract");
        m.goalMin = prefs.num("goalMin", 240);
        m.focusMin = Focus.minutesToday(prefs);
        m.streak = Focus.streak(prefs);
        m.showIcons = prefs.bool("dashIcons", true);
        dash.bind(m, access);
    }

    private void chooseGoal() {
        final int[] vals = {60, 120, 180, 240, 300, 360, 480};
        String[] items = new String[vals.length];
        for (int i = 0; i < vals.length; i++) items[i] = dur(vals[i] * 60000L);
        choose(t("dash_goal_pick"), items, (d, which) -> {
            prefs.putNum("goalMin", vals[which]);
            afterChange();
        });
    }

    // ------------------------------------------------------------ app list

    private final class AppAdapter extends BaseAdapter {
        @Override
        public int getCount() {
            return results.size();
        }

        @Override
        public Object getItem(int i) {
            return results.get(i);
        }

        @Override
        public long getItemId(int i) {
            return i;
        }

        @Override
        public View getView(int i, View v, ViewGroup parent) {
            TextView tv;
            if (v instanceof TextView) {
                tv = (TextView) v;
            } else {
                tv = new TextView(MainActivity.this);
                tv.setTextSize(22);
                tv.setPadding(dp(4), dp(12), dp(4), dp(12));
            }
            tv.setTextColor(fg);
            tv.setText(results.get(i).display);
            return tv;
        }
    }

    private void buildDrawer() {
        drawerView = new LinearLayout(this);
        drawerView.setOrientation(LinearLayout.VERTICAL);
        drawerView.setPadding(dp(24), dp(16), dp(24), dp(8));

        searchBox = new EditText(this);
        searchBox.setBackground(null);
        searchBox.setSingleLine(true);
        searchBox.setTextSize(24);
        searchBox.setTextColor(fg);
        searchBox.setHintTextColor(dim);
        searchBox.setHint(t("search_hint"));
        searchBox.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        searchBox.setImeOptions(EditorInfo.IME_ACTION_GO);
        searchBox.setPadding(dp(4), dp(10), dp(4), dp(10));
        searchBox.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                filter(s.toString());
            }
        });
        searchBox.setOnEditorActionListener((v, actionId, event) -> {
            if (!results.isEmpty()) openApp(results.get(0));
            return true;
        });

        adapter = new AppAdapter();
        drawerListView = new ListView(this);
        drawerListView.setAdapter(adapter);
        drawerListView.setDivider(null);
        drawerListView.setDividerHeight(0);
        drawerListView.setVerticalScrollBarEnabled(false);
        drawerListView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        drawerListView.setSelector(android.R.color.transparent);
        drawerListView.setOnItemClickListener((p, v, pos, id) -> {
            if (pos >= 0 && pos < results.size()) openApp(results.get(pos));
        });
        drawerListView.setOnItemLongClickListener((p, v, pos, id) -> {
            if (pos >= 0 && pos < results.size()) showAppMenu(results.get(pos));
            return true;
        });

        emptyHint = text(t("no_results"), 16, dim);
        emptyHint.setPadding(dp(4), dp(16), dp(4), 0);
        emptyHint.setVisibility(View.GONE);

        drawerView.addView(searchBox);
        drawerView.addView(emptyHint);
        drawerView.addView(drawerListView, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
    }

    private void openDrawer() {
        mode = 1;
        setScreenAnimated(drawerView);
        searchBox.setText("");
        if (prefs.bool("autoKb", true)) {
            searchBox.requestFocus();
            handler.postDelayed(() -> {
                InputMethodManager im = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                if (im != null) im.showSoftInput(searchBox, InputMethodManager.SHOW_IMPLICIT);
            }, 150);
        }
    }

    private void hideKeyboard() {
        InputMethodManager im = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (im != null && root != null) im.hideSoftInputFromWindow(root.getWindowToken(), 0);
    }

    private void filter(String q) {
        String n = Norm.n(q);
        List<AppInfo> starts = new ArrayList<AppInfo>();
        List<AppInfo> contains = new ArrayList<AppInfo>();
        for (AppInfo a : visibleApps()) {
            if (n.length() == 0 || a.norm.startsWith(n)) starts.add(a);
            else if (a.all.contains(n)) contains.add(a);
        }
        starts.addAll(contains);
        results = starts;
        adapter.notifyDataSetChanged();
        emptyHint.setVisibility(results.isEmpty() ? View.VISIBLE : View.GONE);
        scheduleAuto(n);
    }

    private void scheduleAuto(String n) {
        if (autoRun != null) {
            handler.removeCallbacks(autoRun);
            autoRun = null;
        }
        if (!prefs.bool("autoOpen", true) || n.length() < 2 || results.size() != 1) return;
        final AppInfo a = results.get(0);
        autoRun = () -> {
            autoRun = null;
            if (mode == 1) openApp(a);
        };
        handler.postDelayed(autoRun, 700);
    }

    // ----------------------------------------------------------- launching

    private void openApp(final AppInfo a) {
        boolean distracting = prefs.set("distract").contains(a.pkg);
        if (distracting && Focus.active(prefs)) {
            showBlocked();
            return;
        }
        int lim = prefs.num("limit_" + a.pkg, 0);
        if (lim > 0 && Usage.granted(this) && Usage.usedMs(this, a.pkg) >= lim * 60000L) {
            showDelayDialog(t("limit_title"), f("limit_msg", a.display, lim), 15, t("override"), () -> launch(a));
            return;
        }
        int secs = prefs.num("pause", 5);
        if (distracting && secs > 0) {
            showDelayDialog(t("pause_title"), t("pause_msg"), secs, t("go_on"), () -> launch(a));
            return;
        }
        launch(a);
    }

    private void launch(AppInfo a) {
        hideKeyboard();
        try {
            Intent i = new Intent(Intent.ACTION_MAIN);
            i.addCategory(Intent.CATEGORY_LAUNCHER);
            i.setClassName(a.pkg, a.cls);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
            showHome();
            startActivity(i);
            Usage.invalidate();
        } catch (Exception e) {
            toast(t("err_open"));
        }
    }

    private void showBlocked() {
        AlertDialog.Builder b = dialog().setTitle(t("blocked_title")).setMessage(t("blocked_msg"))
                .setPositiveButton(t("ok"), null);
        if (Focus.sessionActive(prefs)) {
            b.setNeutralButton(t("end_session"), (d, w) -> endSessionWithDelay());
        }
        b.show();
    }

    private void endSessionWithDelay() {
        showDelayDialog(t("end_session"), t("end_session_msg"), 10, t("end_session"), () -> {
            Focus.endSession(prefs);
            afterChange();
        });
    }

    private void onFocusTap() {
        if (Focus.sessionActive(prefs)) {
            endSessionWithDelay();
            return;
        }
        final int[] mins = {15, 25, 45, 60, 90};
        String[] items = new String[mins.length];
        for (int i = 0; i < mins.length; i++) items[i] = f("minutes", mins[i]);
        choose(t("focus_pick"), items, (d, which) -> startSession(mins[which]));
    }

    private void startSession(int minutes) {
        Focus.startSession(prefs, minutes);
        afterChange();
    }

    private void swipeAction(String k) {
        String key = prefs.str(k, "");
        AppInfo a = (key == null || key.length() == 0) ? null : appForKey(key);
        if (a != null) {
            openApp(a);
            return;
        }
        try {
            Intent i = "swipeLeft".equals(k)
                    ? new Intent(Intent.ACTION_DIAL)
                    : new Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        } catch (Exception e) {
            toast(t("err_open"));
        }
    }

    private void lockScreen() {
        LockService s = LockService.instance;
        if (s != null && Build.VERSION.SDK_INT >= 28 && s.lock()) return;
        if (adminActive()) {
            try {
                DevicePolicyManager dpm = (DevicePolicyManager) getSystemService(Context.DEVICE_POLICY_SERVICE);
                dpm.lockNow();
                return;
            } catch (Throwable ignore) {
                // fall through to the hint below
            }
        }
        toast(Build.VERSION.SDK_INT < 28 ? t("lock_old") : t("lock_enable"));
    }

    private void openNotifications() {
        try {
            Object bar = getSystemService("statusbar");
            Class<?> cls = Class.forName("android.app.StatusBarManager");
            cls.getMethod("expandNotificationsPanel").invoke(bar);
        } catch (Throwable e) {
            LockService s = LockService.instance;
            if (s != null) s.notifications();
        }
    }

    // ------------------------------------------------------------ app menu

    private void afterChange() {
        if (mode == 0) {
            refreshHome();
        } else if (mode == 1) {
            filter(searchBox.getText().toString());
        } else if (mode == 2) {
            rebuildSettings();
        } else {
            refreshHome();
            bindDash(Usage.snapshot(), Usage.granted(this));
        }
    }

    private void showAppMenu(final AppInfo a) {
        final List<String> labels = new ArrayList<String>();
        final List<Runnable> acts = new ArrayList<Runnable>();
        final List<String> home = prefs.list("home");
        if (home.contains(a.key)) {
            labels.add(t("m_unhome"));
            acts.add(() -> {
                home.remove(a.key);
                prefs.putList("home", home);
                afterChange();
            });
            if (home.indexOf(a.key) > 0) {
                labels.add(t("m_up"));
                acts.add(() -> {
                    int i = home.indexOf(a.key);
                    Collections.swap(home, i, i - 1);
                    prefs.putList("home", home);
                    afterChange();
                });
            }
        } else {
            labels.add(t("m_home"));
            acts.add(() -> addToHome(a));
        }
        labels.add(t("m_rename"));
        acts.add(() -> renameApp(a));
        labels.add(t("m_hide"));
        acts.add(() -> {
            Set<String> h = prefs.set("hidden");
            h.add(a.pkg);
            prefs.putSet("hidden", h);
            afterChange();
        });
        final boolean distracting = prefs.set("distract").contains(a.pkg);
        labels.add(distracting ? t("m_undistract") : t("m_distract"));
        acts.add(() -> {
            Set<String> s = prefs.set("distract");
            if (distracting) s.remove(a.pkg);
            else s.add(a.pkg);
            prefs.putSet("distract", s);
            afterChange();
        });
        labels.add(t("m_limit"));
        acts.add(() -> chooseLimit(a.pkg));
        labels.add(t("m_info"));
        acts.add(() -> startSafe(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                Uri.parse("package:" + a.pkg))));
        labels.add(t("m_uninstall"));
        acts.add(() -> startSafe(new Intent(Intent.ACTION_DELETE, Uri.parse("package:" + a.pkg))));

        final String[] arr = labels.toArray(new String[0]);
        dialog().setTitle(a.display).setItems(arr, (d, which) -> acts.get(which).run()).show();
    }

    private void addToHome(AppInfo a) {
        List<String> h = prefs.list("home");
        int max = prefs.num("homeMax", 5);
        if (h.size() >= max) {
            toast(f("home_full", max));
            return;
        }
        h.add(a.key);
        prefs.putList("home", h);
        prefs.putStr("hl_" + a.key, a.display);
        toast(t("added"));
        afterChange();
    }

    private void renameApp(final AppInfo a) {
        prompt(t("rename"), a.display, s -> {
            if (s.length() == 0) prefs.remove("name_" + a.key);
            else prefs.putStr("name_" + a.key, s);
            AppRepo.refresh(this, this::onAppsLoaded);
        });
    }

    private void chooseLimit(final String pkg) {
        final int[] vals = {0, 15, 30, 45, 60, 90, 120, 180};
        String[] items = new String[vals.length];
        for (int i = 0; i < vals.length; i++) {
            items[i] = vals[i] == 0 ? t("no_limit") : f("minutes", vals[i]);
        }
        choose(t("limit_pick"), items, (d, which) -> {
            if (vals[which] == 0) prefs.remove("limit_" + pkg);
            else prefs.putNum("limit_" + pkg, vals[which]);
            if (vals[which] > 0 && !Usage.granted(this)) showUsageHelp();
            if (mode == 2) rebuildSettings();
        });
    }

    // ------------------------------------------------------------ settings

    private TextView section(String s) {
        TextView v = text(s, 13, dim);
        v.setPadding(0, dp(24), 0, dp(4));
        return v;
    }

    private View row(String title, String value, View.OnClickListener l) {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.VERTICAL);
        r.setPadding(0, dp(11), 0, dp(11));
        r.addView(text(title, 18, fg));
        if (value != null && value.length() > 0) r.addView(text(value, 14, dim));
        r.setOnClickListener(l);
        return r;
    }

    private View toggleRow(String title, final String key, final boolean def, final Runnable after) {
        boolean on = prefs.bool(key, def);
        return row(title, on ? t("on") : t("off"), v -> {
            prefs.putBool(key, !prefs.bool(key, def));
            if (after != null) after.run();
            rebuildSettings();
        });
    }

    private String mark(boolean ok) {
        return ok ? "\u2713  " : "\u2717  ";
    }

    private String idxLabel(String[] labels, String key, int def) {
        int i = prefs.num(key, def);
        return labels[Math.max(0, Math.min(labels.length - 1, i))];
    }

    private void chooseIdx(String title, String[] labels, final String key) {
        choose(title, labels, (d, which) -> {
            prefs.putNum(key, which);
            rebuildSettings();
        });
    }

    private void chooseNum(String title, final int[] vals, final String key) {
        String[] items = new String[vals.length];
        for (int i = 0; i < vals.length; i++) {
            items[i] = vals[i] == 0 ? t("off") : String.valueOf(vals[i]);
        }
        choose(title, items, (d, which) -> {
            prefs.putNum(key, vals[which]);
            rebuildSettings();
        });
    }

    private String swipeLabel(String key, String dflt) {
        String k = prefs.str(key, "");
        if (k == null || k.length() == 0) return dflt;
        AppInfo a = findKey(k);
        return a == null ? dflt : a.display;
    }

    private void chooseSwipeApp(final String key, String title, String dflt) {
        final List<AppInfo> list = new ArrayList<AppInfo>(AppRepo.get());
        String[] items = new String[list.size() + 1];
        items[0] = dflt;
        for (int i = 0; i < list.size(); i++) items[i + 1] = list.get(i).display;
        choose(title, items, (d, which) -> {
            if (which == 0) prefs.remove(key);
            else prefs.putStr(key, list.get(which - 1).key);
            rebuildSettings();
        });
    }

    private void rebuildSettings() {
        int y = settingsScroll == null ? 0 : settingsScroll.getScrollY();
        showSettings();
        final int fy = y;
        settingsScroll.post(() -> settingsScroll.scrollTo(0, fy));
    }

    private void showSettings() {
        mode = 2;
        hideKeyboard();
        settingsScroll = new ScrollView(this);
        settingsScroll.setBackgroundColor(bg);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(24), dp(16), dp(24), dp(48));
        settingsScroll.addView(col);

        col.addView(text(t("settings"), 30, fg));
        TextView back = text(t("done"), 16, dim);
        back.setPadding(0, dp(8), 0, dp(8));
        back.setOnClickListener(v -> showHome());
        col.addView(back);

        // ---- setup
        col.addView(section(t("sec_setup")));
        col.addView(row(mark(isDefaultLauncher()) + t("set_default"), t("set_default_d"),
                v -> startSafe(new Intent(Settings.ACTION_HOME_SETTINGS))));
        boolean lockOn = lockServiceEnabled();
        String lockState = lockOn ? (LockService.instance != null ? t("lock_ready") : t("lock_enabled"))
                : t("set_lock_d");
        col.addView(row(mark(lockOn) + t("set_lock"), lockState, v -> showA11yHelp()));
        boolean adminOn = adminActive();
        col.addView(row(mark(adminOn) + t("set_admin"), adminOn ? t("admin_on") : t("admin_off"),
                v -> toggleAdmin()));
        col.addView(row(mark(Usage.granted(this)) + t("set_usage"), t("set_usage_d"),
                v -> showUsageHelp()));
        col.addView(row(t("set_wake"), t("set_wake_d"), v -> showWakeHelp()));
        col.addView(row(t("diag_title"), t("diag_d"), v -> showDiag()));

        // ---- dashboard
        col.addView(section(t("sec_dash")));
        col.addView(row(t("dash_open"), "", v -> {
            showHome();
            pager.showPage(1, true);
        }));
        col.addView(row(t("dash_goal"), dur(prefs.num("goalMin", 240) * 60000L), v -> chooseGoal()));
        col.addView(toggleRow(t("dash_icons"), "dashIcons", true, null));

        // ---- home screen
        col.addView(section(t("sec_home")));
        col.addView(row(t("home_count"), String.valueOf(prefs.num("homeMax", 5)),
                v -> chooseNum(t("home_count"), new int[]{2, 3, 4, 5, 6, 7, 8}, "homeMax")));
        final String[] sizes = {t("small"), t("medium"), t("large")};
        col.addView(row(t("text_size"), idxLabel(sizes, "textSize", 1),
                v -> chooseIdx(t("text_size"), sizes, "textSize")));
        final String[] aligns = {t("align_start"), t("align_center"), t("align_end")};
        col.addView(row(t("align"), idxLabel(aligns, "align", 0),
                v -> chooseIdx(t("align"), aligns, "align")));
        String th = prefs.str("theme", "dark");
        String thLabel = "auto".equals(th) ? t("auto") : "light".equals(th) ? t("light") : t("dark");
        col.addView(row(t("theme"), thLabel, v -> choose(t("theme"),
                new String[]{t("auto"), t("dark"), t("light")}, (d, which) -> {
                    prefs.putStr("theme", which == 0 ? "auto" : which == 1 ? "dark" : "light");
                    recreate();
                })));
        String lang = prefs.str("lang", "auto");
        String langLabel = "ar".equals(lang) ? t("lang_ar") : "en".equals(lang) ? t("lang_en") : t("auto");
        col.addView(row(t("language"), langLabel, v -> choose(t("language"),
                new String[]{t("auto"), t("lang_ar"), t("lang_en")}, (d, which) -> {
                    prefs.putStr("lang", which == 1 ? "ar" : which == 2 ? "en" : "auto");
                    recreate();
                })));
        col.addView(toggleRow(t("status_bar"), "statusBar", true, this::applyWindow));
        col.addView(toggleRow(t("show_usage"), "showUsage", false, () -> {
            if (prefs.bool("showUsage", false) && !Usage.granted(this)) showUsageHelp();
        }));

        // ---- gestures and search
        col.addView(section(t("sec_gest")));
        col.addView(toggleRow(t("dt_lock"), "dtLock", true, null));
        col.addView(row(t("swipe_right"), swipeLabel("swipeRight", t("default_right")),
                v -> chooseSwipeApp("swipeRight", t("swipe_right"), t("default_right"))));
        col.addView(toggleRow(t("auto_open"), "autoOpen", true, null));
        col.addView(toggleRow(t("auto_kb"), "autoKb", true, null));

        // ---- focus
        col.addView(section(t("sec_focus")));
        col.addView(row(Focus.sessionActive(prefs) ? t("end_session") : t("start_session"), "",
                v -> onFocusTap()));
        col.addView(row(t("distract_apps"), f("n_apps", prefs.set("distract").size()),
                v -> pickApps(t("distract_apps"), "distract")));
        int secs = prefs.num("pause", 5);
        col.addView(row(t("pause_secs"), secs == 0 ? t("off") : f("seconds", secs),
                v -> chooseNum(t("pause_secs"), new int[]{0, 3, 5, 10, 15}, "pause")));
        col.addView(row(t("limits"), f("n_apps", limitedPkgs().size()), v -> showLimits()));
        col.addView(row(t("schedules"), String.valueOf(Focus.schedules(prefs).size()),
                v -> showSchedules()));

        // ---- apps
        col.addView(section(t("sec_apps")));
        col.addView(row(t("hidden_apps"), f("n_apps", prefs.set("hidden").size()),
                v -> pickApps(t("hidden_apps"), "hidden")));

        // ---- about
        col.addView(section(t("sec_about")));
        col.addView(row(t("about_title") + " " + VERSION, t("about_d"), null));

        setScreenAnimated(settingsScroll);
    }

    private void pickApps(String title, final String key) {
        final LinkedHashMap<String, String> m = new LinkedHashMap<String, String>();
        for (AppInfo a : AppRepo.get()) {
            if (!m.containsKey(a.pkg)) m.put(a.pkg, a.display);
        }
        final String[] pk = m.keySet().toArray(new String[0]);
        String[] names = m.values().toArray(new String[0]);
        final Set<String> sel = prefs.set(key);
        final boolean[] on = new boolean[pk.length];
        for (int i = 0; i < pk.length; i++) on[i] = sel.contains(pk[i]);
        dialog().setTitle(title)
                .setMultiChoiceItems(names, on, (d, which, checked) -> {
                    if (checked) sel.add(pk[which]);
                    else sel.remove(pk[which]);
                })
                .setPositiveButton(t("save"), (d, w) -> {
                    prefs.putSet(key, sel);
                    afterChange();
                })
                .setNegativeButton(t("cancel"), null)
                .show();
    }

    // ---- daily limits

    private List<String> limitedPkgs() {
        List<String> out = new ArrayList<String>();
        for (AppInfo a : AppRepo.get()) {
            if (!out.contains(a.pkg) && prefs.num("limit_" + a.pkg, 0) > 0) out.add(a.pkg);
        }
        return out;
    }

    private void showLimits() {
        final List<String> pk = limitedPkgs();
        String[] items = new String[pk.size() + 1];
        for (int i = 0; i < pk.size(); i++) {
            items[i] = labelFor(pk.get(i)) + "  \u2014  " + f("minutes", prefs.num("limit_" + pk.get(i), 0));
        }
        items[pk.size()] = "+  " + t("add");
        choose(t("limits"), items, (d, which) -> {
            if (which < pk.size()) chooseLimit(pk.get(which));
            else pickAppForLimit();
        });
    }

    private void pickAppForLimit() {
        final List<String> pk = new ArrayList<String>();
        List<String> names = new ArrayList<String>();
        for (AppInfo a : AppRepo.get()) {
            if (!pk.contains(a.pkg)) {
                pk.add(a.pkg);
                names.add(a.display);
            }
        }
        choose(t("limits"), names.toArray(new String[0]), (d, which) -> chooseLimit(pk.get(which)));
    }

    // ---- schedules

    private String hhmm(int minutes) {
        return String.format(Locale.US, "%02d:%02d", minutes / 60, minutes % 60);
    }

    private Locale dayLocale() {
        return ar ? Locale.forLanguageTag("ar-u-nu-latn") : Locale.ENGLISH;
    }

    private String[] dayLabels() {
        String[] w = new DateFormatSymbols(dayLocale()).getWeekdays();
        String[] out = new String[7];
        for (int i = 0; i < 7; i++) out[i] = w[i + 1];
        return out;
    }

    private String daysText(int mask) {
        if (mask == 127) return t("every_day");
        String[] w = new DateFormatSymbols(dayLocale()).getShortWeekdays();
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 7; i++) {
            if (((mask >> i) & 1) != 0) {
                if (sb.length() > 0) sb.append(' ');
                sb.append(w[i + 1]);
            }
        }
        return sb.toString();
    }

    private String describe(Focus.Sched s) {
        return (s.on ? "\u25CF " : "\u25CB ") + s.name + "  " + daysText(s.days) + "  "
                + hhmm(s.start) + " - " + hhmm(s.end);
    }

    private void showSchedules() {
        final List<Focus.Sched> list = Focus.schedules(prefs);
        String[] items = new String[list.size() + 1];
        for (int i = 0; i < list.size(); i++) items[i] = describe(list.get(i));
        items[list.size()] = "+  " + t("add");
        choose(t("schedules"), items, (d, which) -> {
            if (which == list.size()) scheduleWizard(new Focus.Sched(), -1);
            else editSchedule(list, which);
        });
    }

    private void editSchedule(final List<Focus.Sched> list, final int idx) {
        final Focus.Sched s = list.get(idx);
        choose(s.name, new String[]{t("s_toggle"), t("s_edit"), t("s_delete")}, (d, which) -> {
            if (which == 0) {
                s.on = !s.on;
                Focus.save(prefs, list);
                rebuildSettings();
            } else if (which == 1) {
                scheduleWizard(s, idx);
            } else {
                list.remove(idx);
                Focus.save(prefs, list);
                rebuildSettings();
            }
        });
    }

    private void scheduleWizard(final Focus.Sched s, final int index) {
        prompt(t("sched_name"), s.name, name -> {
            s.name = name.length() == 0 ? t("sched_default") : name;
            pickDays(s, () -> pickTime(t("sched_start"), s.start, st -> {
                s.start = st;
                pickTime(t("sched_end"), s.end, en -> {
                    s.end = en;
                    List<Focus.Sched> all = Focus.schedules(prefs);
                    if (index < 0 || index >= all.size()) all.add(s);
                    else all.set(index, s);
                    Focus.save(prefs, all);
                    rebuildSettings();
                });
            }));
        });
    }

    private void pickDays(final Focus.Sched s, final Runnable next) {
        final String[] names = dayLabels();
        final boolean[] on = new boolean[7];
        for (int i = 0; i < 7; i++) on[i] = ((s.days >> i) & 1) != 0;
        dialog().setTitle(t("sched_days"))
                .setMultiChoiceItems(names, on, (d, which, checked) -> on[which] = checked)
                .setPositiveButton(t("next"), (d, w) -> {
                    int mask = 0;
                    for (int i = 0; i < 7; i++) {
                        if (on[i]) mask |= (1 << i);
                    }
                    s.days = mask == 0 ? 127 : mask;
                    next.run();
                })
                .setNegativeButton(t("cancel"), null)
                .show();
    }

    private void pickTime(String title, int minutes, final IntCb cb) {
        int theme = dark ? android.R.style.Theme_DeviceDefault_Dialog
                : android.R.style.Theme_DeviceDefault_Light_Dialog;
        TimePickerDialog d = new TimePickerDialog(this, theme,
                (view, h, m) -> cb.done(h * 60 + m), minutes / 60, minutes % 60, true);
        d.setTitle(title);
        d.show();
    }

    // ---- permissions, help and diagnostics

    private boolean isSamsung() {
        return "samsung".equalsIgnoreCase(Build.MANUFACTURER);
    }

    private void showA11yHelp() {
        String path = isSamsung() ? t("a11y_path_samsung") : t("a11y_path_generic");
        dialog().setTitle(t("a11y_title")).setMessage(f("a11y_msg", path))
                .setPositiveButton(t("a11y_open"),
                        (d, w) -> startSafe(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)))
                .setNeutralButton(t("m_info"),
                        (d, w) -> startSafe(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                                Uri.parse("package:" + getPackageName()))))
                .setNegativeButton(t("cancel"), null)
                .show();
    }

    private void showUsageHelp() {
        dialog().setTitle(t("usage_title")).setMessage(t("usage_msg"))
                .setPositiveButton(t("open_settings"),
                        (d, w) -> startSafe(new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)))
                .setNegativeButton(t("cancel"), null)
                .show();
    }

    private void showWakeHelp() {
        String path = isSamsung() ? t("wake_path_samsung") : t("wake_path_generic");
        dialog().setTitle(t("wake_title")).setMessage(f("wake_msg", path))
                .setPositiveButton(t("wake_open"),
                        (d, w) -> startSafe(new Intent(Settings.ACTION_DISPLAY_SETTINGS)))
                .setNegativeButton(t("cancel"), null)
                .show();
    }

    private ComponentName adminName() {
        return new ComponentName(this, AdminReceiver.class);
    }

    private boolean adminActive() {
        try {
            DevicePolicyManager dpm = (DevicePolicyManager) getSystemService(Context.DEVICE_POLICY_SERVICE);
            return dpm != null && dpm.isAdminActive(adminName());
        } catch (Throwable e) {
            return false;
        }
    }

    private void toggleAdmin() {
        if (adminActive()) {
            try {
                DevicePolicyManager dpm = (DevicePolicyManager) getSystemService(Context.DEVICE_POLICY_SERVICE);
                dpm.removeActiveAdmin(adminName());
            } catch (Throwable ignore) {
                // nothing to do
            }
            rebuildSettings();
            return;
        }
        Intent i = new Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN);
        i.putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, adminName());
        i.putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, t("admin_explain"));
        startSafe(i);
    }

    private String yn(boolean b) {
        return b ? "yes" : "no";
    }

    private String diagReport() {
        StringBuilder b = new StringBuilder();
        b.append("Focus Launcher ").append(VERSION).append('\n');
        b.append("Android ").append(Build.VERSION.RELEASE).append(" (SDK ").append(Build.VERSION.SDK_INT).append(")\n");
        b.append(Build.MANUFACTURER).append(' ').append(Build.MODEL).append('\n');
        b.append("Language: ").append(ar ? "ar" : "en").append('\n');
        b.append("Default launcher: ").append(yn(isDefaultLauncher())).append('\n');
        boolean svc = lockServiceEnabled();
        b.append("Accessibility service: ")
                .append(svc ? (LockService.instance != null ? "on, connected" : "on, not connected") : "off")
                .append('\n');
        b.append("Device admin: ").append(yn(adminActive())).append('\n');
        b.append("Usage access: ").append(yn(Usage.granted(this))).append('\n');
        b.append("Apps: ").append(AppRepo.get().size()).append(" (").append(AppRepo.loadMs).append(" ms)\n");
        UsageData u = Usage.snapshot();
        b.append("Usage: ").append(u == null ? "none" : (u.computeMs + " ms, " + u.top.size() + " apps")).append('\n');
        String crash = prefs.str("lastCrash", null);
        b.append("Last crash: ").append(crash == null ? "none" : "\n" + crash);
        return b.toString();
    }

    private void showDiag() {
        final String rep = diagReport();
        dialog().setTitle(t("diag_title")).setMessage(rep)
                .setPositiveButton(t("diag_copy"), (d, w) -> {
                    ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                    if (cm != null) {
                        cm.setPrimaryClip(ClipData.newPlainText("Focus Launcher", rep));
                        toast(t("diag_copied"));
                    }
                })
                .setNegativeButton(t("close"), null)
                .show();
    }

    private void onboard() {
        prefs.putBool("onboarded", true);
        dialog().setTitle(t("welcome_title")).setMessage(t("welcome_msg"))
                .setPositiveButton(t("open_settings"), (d, w) -> showSettings())
                .setNegativeButton(t("later"), null)
                .show();
    }

    private boolean isDefaultLauncher() {
        Intent i = new Intent(Intent.ACTION_MAIN);
        i.addCategory(Intent.CATEGORY_HOME);
        ResolveInfo ri = getPackageManager().resolveActivity(i, PackageManager.MATCH_DEFAULT_ONLY);
        return ri != null && ri.activityInfo != null
                && getPackageName().equals(ri.activityInfo.packageName);
    }

    private boolean lockServiceEnabled() {
        String s = Settings.Secure.getString(getContentResolver(),
                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        if (s == null || s.length() == 0) return false;
        for (String part : s.split(":")) {
            ComponentName cn = ComponentName.unflattenFromString(part);
            if (cn != null && cn.getPackageName().equals(getPackageName())
                    && cn.getClassName().equals(LockService.class.getName())) {
                return true;
            }
        }
        return false;
    }
}
