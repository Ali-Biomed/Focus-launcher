package com.focuslauncher;

import android.graphics.drawable.Drawable;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** One snapshot of the user's screen time. */
final class UsageData {
    long at;
    long computeMs;
    long totalMs;
    long yesterdayMs;
    int pickups;
    final long[] hours = new long[24];
    final long[] days = new long[7];
    final Map<String, Long> perApp = new HashMap<String, Long>();
    final List<String> top = new ArrayList<String>();
    final Map<String, Drawable> icons = new HashMap<String, Drawable>();
}
