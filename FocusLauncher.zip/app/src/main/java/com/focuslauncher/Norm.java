package com.focuslauncher;

import java.util.Locale;

final class Norm {
    private Norm() {}

    /** Lower-cases and normalizes Arabic so search ignores diacritics, hamza forms and digit styles. */
    static String n(String s) {
        if (s == null) return "";
        String low = s.toLowerCase(Locale.ROOT);
        StringBuilder b = new StringBuilder(low.length());
        for (int i = 0; i < low.length(); i++) {
            char c = low.charAt(i);
            if ((c >= '\u064B' && c <= '\u065F') || c == '\u0670' || c == '\u0640') continue;
            switch (c) {
                case '\u0623':
                case '\u0625':
                case '\u0622':
                case '\u0671':
                    c = '\u0627';
                    break;
                case '\u0649':
                    c = '\u064A';
                    break;
                case '\u0629':
                    c = '\u0647';
                    break;
                case '\u0624':
                    c = '\u0648';
                    break;
                case '\u0626':
                    c = '\u064A';
                    break;
                default:
                    if (c >= '\u0660' && c <= '\u0669') c = (char) ('0' + (c - '\u0660'));
                    else if (c >= '\u06F0' && c <= '\u06F9') c = (char) ('0' + (c - '\u06F0'));
                    break;
            }
            b.append(c);
        }
        return b.toString().trim();
    }
}
