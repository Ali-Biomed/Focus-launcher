package com.focuslauncher;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Small wrapper around SharedPreferences. */
final class Prefs {
    private final SharedPreferences sp;

    Prefs(Context c) {
        sp = c.getSharedPreferences("focus_prefs", Context.MODE_PRIVATE);
    }

    String str(String k, String d) { return sp.getString(k, d); }

    void putStr(String k, String v) { sp.edit().putString(k, v).apply(); }

    /** Writes immediately (used when the process may die right after). */
    void putStrNow(String k, String v) { sp.edit().putString(k, v).commit(); }

    int num(String k, int d) { return sp.getInt(k, d); }

    void putNum(String k, int v) { sp.edit().putInt(k, v).apply(); }

    long lng(String k, long d) { return sp.getLong(k, d); }

    void putLng(String k, long v) { sp.edit().putLong(k, v).apply(); }

    boolean bool(String k, boolean d) { return sp.getBoolean(k, d); }

    void putBool(String k, boolean v) { sp.edit().putBoolean(k, v).apply(); }

    void remove(String k) { sp.edit().remove(k).apply(); }

    /** Returns a copy, so callers may modify it freely. */
    Set<String> set(String k) {
        Set<String> s = sp.getStringSet(k, null);
        return s == null ? new HashSet<String>() : new HashSet<String>(s);
    }

    void putSet(String k, Set<String> v) {
        sp.edit().putStringSet(k, new HashSet<String>(v)).apply();
    }

    /** Ordered list stored as one string separated by new lines. */
    List<String> list(String k) {
        String s = sp.getString(k, "");
        List<String> out = new ArrayList<String>();
        if (s == null || s.length() == 0) return out;
        for (String p : s.split("\n")) {
            if (p.length() > 0) out.add(p);
        }
        return out;
    }

    void putList(String k, List<String> v) {
        StringBuilder b = new StringBuilder();
        for (String s : v) {
            if (b.length() > 0) b.append('\n');
            b.append(s);
        }
        sp.edit().putString(k, b.toString()).apply();
    }
}
