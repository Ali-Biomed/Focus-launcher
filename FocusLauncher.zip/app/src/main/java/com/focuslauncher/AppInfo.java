package com.focuslauncher;

final class AppInfo {
    final String orig;
    final String pkg;
    final String cls;
    final String key;
    String display;
    String norm;
    String all;

    AppInfo(String orig, String pkg, String cls) {
        this.orig = orig;
        this.pkg = pkg;
        this.cls = cls;
        this.key = pkg + "/" + cls;
        setDisplay(orig);
    }

    void setDisplay(String d) {
        display = d;
        norm = Norm.n(d);
        all = norm + " " + Norm.n(orig);
    }
}
