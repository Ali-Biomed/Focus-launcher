package com.focuslauncher;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Rect;
import android.os.Build;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.animation.DecelerateInterpolator;
import android.widget.FrameLayout;

import java.util.ArrayList;
import java.util.List;

/**
 * Holds the home screen and the dashboard side by side. A right-to-left drag pulls the
 * dashboard in, following the finger. It also reports double taps and quick swipes on the home page.
 */
final class GestureLayer extends FrameLayout {

    interface Listener {
        void onDoubleTap();

        void onSwipeUp();

        void onSwipeDown();

        void onSwipeRight();

        /** A drag toward the dashboard just began: a good moment to prepare its data. */
        void onOpening();

        /** The visible page changed: 0 = home, 1 = dashboard. */
        void onPage(int page);
    }

    private View home;
    private View dash;
    private Listener listener;
    private int page = 0;
    private float progress = 0f;
    private boolean dragging = false;
    private boolean dragged = false;
    private float downX;
    private float downY;
    private float startX;
    private float startProgress;
    private long downT;
    private final int slop;
    private final float density;
    private VelocityTracker vt;
    private ValueAnimator settle;
    private final GestureDetector detector;

    GestureLayer(Context c) {
        super(c);
        slop = ViewConfiguration.get(c).getScaledTouchSlop();
        density = c.getResources().getDisplayMetrics().density;
        detector = new GestureDetector(c, new GestureDetector.SimpleOnGestureListener() {
            @Override
            public boolean onDoubleTap(MotionEvent e) {
                if (page == 0 && !dragging && listener != null) listener.onDoubleTap();
                return true;
            }
        });
    }

    void setListener(Listener l) {
        listener = l;
    }

    void setPages(View h, View d) {
        home = h;
        dash = d;
        removeAllViews();
        addView(h, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        addView(d, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        apply(page == 1 ? 1f : 0f);
    }

    int page() {
        return page;
    }

    /** Jumps to a page, with or without animation. Without animation no callback is sent. */
    void showPage(int p, boolean animate) {
        if (settle != null) settle.cancel();
        dragging = false;
        if (!animate) {
            page = p;
            apply(p == 1 ? 1f : 0f);
            return;
        }
        animateTo(p == 1 ? 1f : 0f);
    }

    private static float clamp(float v) {
        return Math.max(0f, Math.min(1f, v));
    }

    private void apply(float p) {
        progress = p;
        int w = getWidth();
        if (home != null) {
            home.setTranslationX(-p * w * 0.25f);
            home.setAlpha(1f - 0.55f * p);
        }
        if (dash != null) {
            dash.setTranslationX((1f - p) * w);
            dash.setVisibility(p <= 0.001f ? View.INVISIBLE : View.VISIBLE);
        }
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        apply(progress);
    }

    @Override
    protected void onLayout(boolean changed, int l, int t, int r, int b) {
        super.onLayout(changed, l, t, r, b);
        if (Build.VERSION.SDK_INT >= 29) {
            // Let the dashboard drag start at the screen edge instead of triggering "Back".
            int w = r - l;
            int h = b - t;
            int ew = (int) (28 * density);
            int eh = Math.min(h, (int) (200 * density));
            int top = (h - eh) / 2;
            List<Rect> rects = new ArrayList<Rect>();
            rects.add(new Rect(w - ew, top, w, top + eh));
            rects.add(new Rect(0, top, ew, top + eh));
            setSystemGestureExclusionRects(rects);
        }
    }

    private void layers(int type) {
        if (home != null) home.setLayerType(type, null);
        if (dash != null) dash.setLayerType(type, null);
    }

    private void animateTo(final float to) {
        if (settle != null) settle.cancel();
        final int target = to > 0.5f ? 1 : 0;
        float dist = Math.abs(to - progress);
        layers(View.LAYER_TYPE_HARDWARE);
        settle = ValueAnimator.ofFloat(progress, to);
        settle.setDuration((long) (160 + 190 * dist));
        settle.setInterpolator(new DecelerateInterpolator(1.6f));
        settle.addUpdateListener(a -> apply((Float) a.getAnimatedValue()));
        settle.addListener(new AnimatorListenerAdapter() {
            private boolean cancelled = false;

            @Override
            public void onAnimationCancel(Animator an) {
                cancelled = true;
            }

            @Override
            public void onAnimationEnd(Animator an) {
                if (cancelled) return;
                boolean changed = page != target;
                page = target;
                apply(to);
                layers(View.LAYER_TYPE_NONE);
                if (changed && listener != null) listener.onPage(page);
            }
        });
        settle.start();
    }

    // ---------------------------------------------------------------- touches

    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
        int a = ev.getActionMasked();
        if (a == MotionEvent.ACTION_DOWN) {
            downX = ev.getX();
            downY = ev.getY();
            downT = ev.getEventTime();
            dragged = false;
            if (settle != null && settle.isRunning()) {
                // the user grabbed the page while it was still moving: settle it at once
                settle.cancel();
                page = progress > 0.5f ? 1 : 0;
                apply(page == 1 ? 1f : 0f);
                layers(View.LAYER_TYPE_NONE);
                if (listener != null) listener.onPage(page);
            }
        }
        if (page == 0) detector.onTouchEvent(ev);
        float ux = ev.getX();
        float uy = ev.getY();
        long ut = ev.getEventTime();
        boolean r = super.dispatchTouchEvent(ev);
        if (a == MotionEvent.ACTION_UP && !dragged && page == 0 && listener != null) {
            flick(ux - downX, uy - downY, ut - downT);
        }
        return r;
    }

    private void flick(float dx, float dy, long dt) {
        if (dt > 900L) return;
        float min = 90f * density;
        float ax = Math.abs(dx);
        float ay = Math.abs(dy);
        if (ay > ax * 1.5f && ay > min) {
            if (dy < 0) listener.onSwipeUp();
            else listener.onSwipeDown();
        } else if (ax > ay * 1.5f && ax > min && dx > 0) {
            listener.onSwipeRight();
        }
    }

    private boolean maybeStartDrag(MotionEvent ev) {
        if (home == null || dash == null) return false;
        if (ev.getActionMasked() != MotionEvent.ACTION_MOVE) return false;
        if (settle != null && settle.isRunning()) return false;
        float dx = ev.getX() - downX;
        float dy = ev.getY() - downY;
        if (Math.abs(dx) < slop * 2 || Math.abs(dx) < Math.abs(dy) * 1.3f) return false;
        boolean open = page == 0 && dx < 0;
        boolean close = page == 1 && dx > 0;
        if (!open && !close) return false;
        dragging = true;
        dragged = true;
        startX = ev.getX();
        startProgress = progress;
        vt = VelocityTracker.obtain();
        vt.addMovement(ev);
        layers(View.LAYER_TYPE_HARDWARE);
        if (open && listener != null) listener.onOpening();
        return true;
    }

    @Override
    public boolean onInterceptTouchEvent(MotionEvent ev) {
        if (dragging) return true;
        return maybeStartDrag(ev);
    }

    @Override
    public boolean onTouchEvent(MotionEvent ev) {
        int a = ev.getActionMasked();
        if (!dragging) {
            if (a == MotionEvent.ACTION_MOVE && maybeStartDrag(ev)) return true;
            return a == MotionEvent.ACTION_DOWN;
        }
        if (vt != null) vt.addMovement(ev);
        if (a == MotionEvent.ACTION_MOVE) {
            float dx = ev.getX() - startX;
            apply(clamp(startProgress - dx / Math.max(1, getWidth())));
        } else if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) {
            finishDrag();
        }
        return true;
    }

    private void finishDrag() {
        dragging = false;
        float vx = 0f;
        if (vt != null) {
            vt.computeCurrentVelocity(1000);
            vx = vt.getXVelocity();
            vt.recycle();
            vt = null;
        }
        boolean toDash;
        if (Math.abs(vx) > 700f * density) toDash = vx < 0f;
        else toDash = progress > 0.4f;
        animateTo(toDash ? 1f : 0f);
    }

    @Override
    protected void onDetachedFromWindow() {
        if (settle != null) settle.cancel();
        super.onDetachedFromWindow();
    }
}
