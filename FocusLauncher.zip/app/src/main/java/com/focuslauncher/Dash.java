package com.focuslauncher;

import android.content.Context;
import android.graphics.Outline;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewOutlineProvider;
import android.view.animation.DecelerateInterpolator;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.text.DateFormatSymbols;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/** The dashboard page: today's screen time, top apps, hours, last week and focus. */
final class Dash {

    interface Actions {
        void startFocus();

        void setGoal();

        void needUsage();

        void appMenu(String pkg);
    }

    /** Everything the dashboard needs to draw itself. */
    static final class Model {
        UsageData usage;
        Map<String, String> names;
        Set<String> distracting;
        int goalMin = 240;
        int focusMin = 0;
        int streak = 0;
        boolean showIcons = true;
    }

    private final Context ctx;
    private final Pal pal;
    private final boolean ar;
    private final Actions act;
    private final float density;

    private ScrollView root;
    private LinearLayout col;
    private TextView dateView;
    private LinearLayout permCard;
    private LinearLayout heroCard;
    private LinearLayout topCard;
    private LinearLayout hoursCard;
    private LinearLayout weekCard;
    private LinearLayout focusCard;
    private final List<View> cards = new ArrayList<View>();

    private Charts.Ring ring;
    private TextView ringMain;
    private TextView ringSub;
    private TextView tilePickups;
    private TextView tileVs;
    private TextView tileFocus;
    private TextView tileValue;
    private LinearLayout topRows;
    private Charts.Columns hoursChart;
    private Charts.Columns weekChart;
    private LinearLayout weekLabels;
    private TextView hoursNote;
    private TextView weekNote;
    private TextView focusMain;
    private TextView focusSub;
    private TextView shareText;
    private Charts.Bar shareBar;

    private boolean animateNext = true;
    private boolean shown = false;
    private boolean bound = false;
    private Model last;
    private boolean lastAccess;

    Dash(Context c, Pal p, boolean arabic, Actions a) {
        ctx = c;
        pal = p;
        ar = arabic;
        act = a;
        density = c.getResources().getDisplayMetrics().density;
        build();
    }

    View view() {
        return root;
    }

    // ---------------------------------------------------------------- helpers

    private int dp(int v) {
        return (int) (v * density + 0.5f);
    }

    private String t(String key) {
        return S.t(ctx, key);
    }

    private String f(String key, Object... args) {
        return S.f(ctx, key, args);
    }

    private Locale locale() {
        return ar ? Locale.forLanguageTag("ar-u-nu-latn") : Locale.ENGLISH;
    }

    private String dur(long ms) {
        long m = ms / 60000L;
        if (m < 60) return f("dur_m", m);
        return f("dur_hm", m / 60, m % 60);
    }

    private TextView tv(String s, float sp, int color, boolean bold) {
        TextView v = new TextView(ctx);
        v.setText(s);
        v.setTextSize(sp);
        v.setTextColor(color);
        if (bold) v.setTypeface(Typeface.DEFAULT_BOLD);
        return v;
    }

    private LinearLayout card() {
        LinearLayout c = new LinearLayout(ctx);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(18), dp(16), dp(18), dp(18));
        GradientDrawable g = new GradientDrawable();
        g.setColor(pal.card);
        g.setCornerRadius(dp(22));
        g.setStroke(dp(1), pal.stroke);
        c.setBackground(g);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, 0, 0, dp(14));
        col.addView(c, lp);
        cards.add(c);
        return c;
    }

    private TextView cardTitle(LinearLayout card, String s) {
        TextView v = tv(s, 14, pal.dim, true);
        v.setPadding(0, 0, 0, dp(10));
        card.addView(v);
        return v;
    }

    private TextView button(String label, int bgColor, int fgColor, View.OnClickListener l) {
        TextView b = tv(label, 14, fgColor, true);
        b.setGravity(Gravity.CENTER);
        b.setPadding(dp(14), dp(12), dp(14), dp(12));
        GradientDrawable g = new GradientDrawable();
        g.setColor(bgColor);
        g.setCornerRadius(dp(14));
        b.setBackground(g);
        b.setOnClickListener(l);
        return b;
    }

    private LinearLayout tile(String label) {
        LinearLayout t = new LinearLayout(ctx);
        t.setOrientation(LinearLayout.VERTICAL);
        t.setGravity(Gravity.CENTER_HORIZONTAL);
        tileValue = tv("-", 19, pal.text, true);
        tileValue.setGravity(Gravity.CENTER);
        TextView l = tv(label, 11, pal.dim, false);
        l.setGravity(Gravity.CENTER);
        l.setPadding(0, dp(3), 0, 0);
        t.addView(tileValue);
        t.addView(l);
        return t;
    }

    private LinearLayout ltrRow() {
        LinearLayout r = new LinearLayout(ctx);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        return r;
    }

    private ImageView icon(Drawable d) {
        ImageView iv = new ImageView(ctx);
        iv.setImageDrawable(d);
        iv.setOutlineProvider(new ViewOutlineProvider() {
            @Override
            public void getOutline(View v, Outline o) {
                o.setRoundRect(0, 0, v.getWidth(), v.getHeight(), dp(9));
            }
        });
        iv.setClipToOutline(true);
        return iv;
    }

    // ------------------------------------------------------------------ build

    private void build() {
        root = new ScrollView(ctx);
        root.setBackgroundColor(pal.bg);
        root.setVerticalScrollBarEnabled(false);
        root.setOverScrollMode(View.OVER_SCROLL_NEVER);
        col = new LinearLayout(ctx);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(20), dp(18), dp(20), dp(36));
        root.addView(col);

        col.addView(tv(t("dash_title"), 30, pal.text, true));
        dateView = tv("", 14, pal.dim, false);
        dateView.setPadding(0, dp(2), 0, dp(16));
        col.addView(dateView);

        // permission card (only shown when usage access is missing)
        permCard = card();
        TextView need = tv(t("dash_need"), 15, pal.text, false);
        need.setPadding(0, 0, 0, dp(12));
        permCard.addView(need);
        permCard.addView(button(t("dash_enable"), Pal.MINT, 0xFF04130D, v -> act.needUsage()));

        // hero: ring + three tiles
        heroCard = card();
        FrameLayout ringBox = new FrameLayout(ctx);
        ring = new Charts.Ring(ctx, pal.track);
        ringBox.addView(ring, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        LinearLayout center = new LinearLayout(ctx);
        center.setOrientation(LinearLayout.VERTICAL);
        center.setGravity(Gravity.CENTER);
        ringMain = tv("", 34, pal.text, true);
        ringMain.setGravity(Gravity.CENTER);
        ringSub = tv("", 13, pal.dim, false);
        ringSub.setGravity(Gravity.CENTER);
        center.addView(ringMain);
        center.addView(ringSub);
        ringBox.addView(center, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        heroCard.addView(ringBox, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(220)));

        LinearLayout tiles = new LinearLayout(ctx);
        tiles.setOrientation(LinearLayout.HORIZONTAL);
        tiles.setPadding(0, dp(14), 0, 0);
        tiles.addView(tile(t("dash_pickups")), new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        tilePickups = tileValue;
        tiles.addView(tile(t("dash_vs")), new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        tileVs = tileValue;
        tiles.addView(tile(t("dash_focus_min")), new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        tileFocus = tileValue;
        heroCard.addView(tiles);

        // top apps
        topCard = card();
        cardTitle(topCard, t("dash_top"));
        topRows = new LinearLayout(ctx);
        topRows.setOrientation(LinearLayout.VERTICAL);
        topCard.addView(topRows);

        // hours of the day
        hoursCard = card();
        cardTitle(hoursCard, t("dash_hours"));
        hoursChart = new Charts.Columns(ctx, pal.track);
        hoursChart.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        hoursCard.addView(hoursChart, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(110)));
        LinearLayout hl = ltrRow();
        hl.setPadding(0, dp(6), 0, 0);
        String[] hs = {"00", "06", "12", "18"};
        for (String h : hs) {
            TextView x = tv(h, 11, pal.dim, false);
            hl.addView(x, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        }
        hoursCard.addView(hl);
        hoursNote = tv("", 13, pal.dim, false);
        hoursNote.setPadding(0, dp(10), 0, 0);
        hoursCard.addView(hoursNote);

        // last 7 days
        weekCard = card();
        cardTitle(weekCard, t("dash_week"));
        weekChart = new Charts.Columns(ctx, pal.track);
        weekChart.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        weekCard.addView(weekChart, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(110)));
        weekLabels = ltrRow();
        weekLabels.setPadding(0, dp(6), 0, 0);
        for (int i = 0; i < 7; i++) {
            TextView x = tv("", 11, pal.dim, false);
            x.setGravity(Gravity.CENTER);
            x.setMaxLines(1);
            weekLabels.addView(x, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        }
        weekCard.addView(weekLabels);
        weekNote = tv("", 13, pal.dim, false);
        weekNote.setPadding(0, dp(10), 0, 0);
        weekCard.addView(weekNote);

        // focus
        focusCard = card();
        cardTitle(focusCard, t("dash_focus_title"));
        focusMain = tv("", 28, Pal.MINT, true);
        focusSub = tv("", 13, pal.dim, false);
        focusSub.setPadding(0, dp(2), 0, dp(14));
        focusCard.addView(focusMain);
        focusCard.addView(focusSub);
        shareText = tv("", 13, pal.text, false);
        shareText.setPadding(0, 0, 0, dp(8));
        focusCard.addView(shareText);
        shareBar = new Charts.Bar(ctx, pal.track);
        focusCard.addView(shareBar, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(8)));
        LinearLayout btns = new LinearLayout(ctx);
        btns.setOrientation(LinearLayout.HORIZONTAL);
        btns.setPadding(0, dp(16), 0, 0);
        LinearLayout.LayoutParams l1 = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        l1.setMarginEnd(dp(8));
        LinearLayout.LayoutParams l2 = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        btns.addView(button(t("start_session"), Pal.MINT, 0xFF04130D, v -> act.startFocus()), l1);
        btns.addView(button(t("dash_goal_btn"), pal.track, pal.text, v -> act.setGoal()), l2);
        focusCard.addView(btns);

        // nothing is shown until the first numbers arrive
        for (View c : cards) c.setVisibility(View.INVISIBLE);
    }

    // ------------------------------------------------------------------- bind

    private void setDataVisible(boolean on) {
        int vis = on ? View.VISIBLE : View.GONE;
        heroCard.setVisibility(vis);
        topCard.setVisibility(vis);
        hoursCard.setVisibility(vis);
        weekCard.setVisibility(vis);
        focusCard.setVisibility(vis);
        permCard.setVisibility(on ? View.GONE : View.VISIBLE);
    }

    void bind(Model m, boolean access) {
        last = m;
        lastAccess = access;
        dateView.setText(new SimpleDateFormat("EEEE, d MMMM", locale()).format(new Date()));
        setDataVisible(access);
        if (!bound) {
            bound = true;
            if (shown) playIntro();
        }
        if (!access) return;

        boolean fromZero = animateNext;
        animateNext = false;
        UsageData u = m.usage != null ? m.usage : new UsageData();

        // ring
        float goalMs = Math.max(1, m.goalMin) * 60000f;
        float frac = u.totalMs / goalMs;
        boolean warn = frac >= 0.8f;
        ring.set(frac, warn ? Pal.AMBER : Pal.MINT, warn ? Pal.CORAL : Pal.CYAN, fromZero);
        ringMain.setText(dur(u.totalMs));
        ringSub.setText(f("dash_goal_of", dur(m.goalMin * 60000L)));

        // tiles
        tilePickups.setText(String.valueOf(u.pickups));
        long diff = u.totalMs - u.yesterdayMs;
        String sign = diff > 0 ? "+" : (diff < 0 ? "\u2212" : "");
        tileVs.setText(sign + dur(Math.abs(diff)));
        tileVs.setTextColor(diff > 0 ? Pal.AMBER : (diff < 0 ? Pal.MINT : pal.text));
        tileFocus.setText(m.focusMin + " " + t("min_short"));

        bindTop(m, u, fromZero);
        bindHours(u, fromZero);
        bindWeek(u, fromZero);
        bindFocus(m, u, fromZero);
    }

    private void bindTop(final Model m, UsageData u, boolean fromZero) {
        topRows.removeAllViews();
        if (u.top.isEmpty()) {
            topRows.addView(tv(t("dash_no_data"), 14, pal.dim, false));
            return;
        }
        long max = 1L;
        for (String p : u.top) {
            Long v = u.perApp.get(p);
            if (v != null) max = Math.max(max, v);
        }
        int[][] pairs = {{Pal.VIOLET, Pal.CYAN}, {Pal.MINT, Pal.CYAN}, {Pal.VIOLET, Pal.MINT}};
        for (int i = 0; i < u.top.size() && i < 6; i++) {
            final String pkg = u.top.get(i);
            Long vv = u.perApp.get(pkg);
            long ms = vv == null ? 0L : vv;
            boolean bad = m.distracting != null && m.distracting.contains(pkg);
            String name = m.names != null ? m.names.get(pkg) : null;
            if (name == null) name = pkg;

            LinearLayout row = new LinearLayout(ctx);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(0, dp(8), 0, dp(8));
            if (m.showIcons) {
                LinearLayout.LayoutParams ilp = new LinearLayout.LayoutParams(dp(34), dp(34));
                ilp.setMarginEnd(dp(12));
                row.addView(icon(u.icons.get(pkg)), ilp);
            }
            LinearLayout mid = new LinearLayout(ctx);
            mid.setOrientation(LinearLayout.VERTICAL);
            LinearLayout head = new LinearLayout(ctx);
            head.setOrientation(LinearLayout.HORIZONTAL);
            TextView nm = tv(name, 15, pal.text, false);
            nm.setMaxLines(1);
            nm.setEllipsize(TextUtils.TruncateAt.END);
            head.addView(nm, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            TextView tm = tv(dur(ms), 13, pal.dim, false);
            tm.setPadding(dp(10), 0, 0, 0);
            head.addView(tm);
            mid.addView(head);
            Charts.Bar bar = new Charts.Bar(ctx, pal.track);
            LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, dp(7));
            blp.topMargin = dp(7);
            int[] pr = pairs[i % pairs.length];
            bar.set(ms / (float) max, bad ? Pal.AMBER : pr[0], bad ? Pal.CORAL : pr[1], fromZero);
            mid.addView(bar, blp);
            row.addView(mid, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            row.setOnClickListener(v -> act.appMenu(pkg));
            topRows.addView(row);
        }
    }

    private void bindHours(UsageData u, boolean fromZero) {
        long max = 1L;
        int peak = 0;
        for (int i = 0; i < 24; i++) {
            max = Math.max(max, u.hours[i]);
            if (u.hours[i] > u.hours[peak]) peak = i;
        }
        float[] v = new float[24];
        int[] cs = new int[24];
        int soft = pal.dark ? 0xFF3A3566 : 0xFFD6D1FF;
        for (int i = 0; i < 24; i++) {
            v[i] = u.hours[i] / (float) max;
            cs[i] = (i == peak && u.hours[i] > 0L) ? Pal.MINT : Charts.lerp(soft, Pal.VIOLET, v[i]);
        }
        hoursChart.set(v, cs, fromZero);
        if (u.hours[peak] > 0L) {
            hoursNote.setText(f("dash_peak",
                    String.format(Locale.US, "%02d:00 - %02d:00", peak, (peak + 1) % 24)));
        } else {
            hoursNote.setText(t("dash_no_data"));
        }
    }

    private void bindWeek(UsageData u, boolean fromZero) {
        long max = 1L;
        long sum = 0L;
        for (int i = 0; i < 7; i++) {
            max = Math.max(max, u.days[i]);
            sum += u.days[i];
        }
        float[] v = new float[7];
        int[] cs = new int[7];
        for (int i = 0; i < 7; i++) {
            v[i] = u.days[i] / (float) max;
            cs[i] = i == 6 ? Pal.MINT : Pal.VIOLET;
        }
        weekChart.set(v, cs, fromZero);
        String[] wk = new DateFormatSymbols(locale()).getShortWeekdays();
        Calendar now = Calendar.getInstance();
        for (int i = 0; i < 7; i++) {
            Calendar d = (Calendar) now.clone();
            d.add(Calendar.DAY_OF_YEAR, i - 6);
            View child = weekLabels.getChildAt(i);
            if (child instanceof TextView) ((TextView) child).setText(wk[d.get(Calendar.DAY_OF_WEEK)]);
        }
        weekNote.setText(f("dash_avg", dur(sum / 7L)));
    }

    private void bindFocus(Model m, UsageData u, boolean fromZero) {
        focusMain.setText(m.focusMin + " " + t("min_short"));
        focusSub.setText(m.streak > 0 ? f("dash_focus_sub", m.streak) : t("dash_focus_none"));
        long bad = 0L;
        if (m.distracting != null) {
            for (String p : m.distracting) {
                Long v = u.perApp.get(p);
                if (v != null) bad += v;
            }
        }
        int pct = u.totalMs > 0L ? (int) Math.min(100L, bad * 100L / u.totalMs) : 0;
        shareText.setText(f("dash_share", pct));
        shareBar.set(pct / 100f, Pal.AMBER, Pal.CORAL, fromZero);
    }

    private void playIntro() {
        for (int i = 0; i < cards.size(); i++) {
            View c = cards.get(i);
            if (c.getVisibility() != View.VISIBLE) continue;
            c.setAlpha(0f);
            c.setTranslationY(dp(22));
            c.animate().alpha(1f).translationY(0f).setStartDelay(i * 55L).setDuration(340)
                    .setInterpolator(new DecelerateInterpolator()).start();
        }
    }

    /** Called when the page has slid in: plays the entrance and refreshes the numbers. */
    void onShown() {
        shown = true;
        animateNext = true;
        root.scrollTo(0, 0);
        if (bound) {
            playIntro();
            if (last != null) bind(last, lastAccess);
        }
    }

    void onHidden() {
        shown = false;
    }
}
