package com.focuslauncher;

import android.app.admin.DeviceAdminReceiver;

/** Backup way to lock the screen on phones that block the accessibility service. */
public class AdminReceiver extends DeviceAdminReceiver {
}
