package com.focuslauncher;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;

/** Keeps the app list in memory and loads it away from the UI thread. */
final class AppRepo {
    private AppRepo() {}

    interface Cb {
        void done();
    }

    private static volatile List<AppInfo> apps = new ArrayList<AppInfo>();
    private static volatile boolean loaded = false;
    private static volatile boolean loading = false;
    private static volatile long loadedAt = 0L;
    static volatile long loadMs = 0L;

    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    private static final ExecutorService IO = Executors.newSingleThreadExecutor(new ThreadFactory() {
        @Override
        public Thread newThread(Runnable r) {
            Thread t = new Thread(r, "focus-io");
            t.setDaemon(true);
            return t;
        }
    });

    static List<AppInfo> get() {
        return apps;
    }

    static boolean ready() {
        return loaded;
    }

    static ExecutorService io() {
        return IO;
    }

    static void post(Runnable r) {
        MAIN.post(r);
    }

    /** Reloads in the background and calls cb on the main thread when done. */
    static void refresh(Context c, final Cb cb) {
        final Context app = c.getApplicationContext();
        if (loading) return;
        loading = true;
        IO.execute(new Runnable() {
            @Override
            public void run() {
                long t0 = System.currentTimeMillis();
                try {
                    apps = Apps.load(app, new Prefs(app));
                    loaded = true;
                } catch (Throwable ignore) {
                    // keep the old list
                }
                loadedAt = System.currentTimeMillis();
                loadMs = loadedAt - t0;
                loading = false;
                if (cb != null) {
                    MAIN.post(new Runnable() {
                        @Override
                        public void run() {
                            cb.done();
                        }
                    });
                }
            }
        });
    }

    static void refreshIfStale(Context c, long maxAgeMs, Cb cb) {
        if (loaded && System.currentTimeMillis() - loadedAt < maxAgeMs) return;
        refresh(c, cb);
    }
}
